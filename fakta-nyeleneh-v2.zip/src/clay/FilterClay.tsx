import React from "react";

type Props = {
  id: string;
  seed: number; // berubah tiap langkah stop-motion agar tepi bentuk bergetar
  goyang?: number; // kekuatan getaran tepi
};

// Filter SVG yang membuat bentuk datar tampak seperti tanah liat:
// 1) tepi bergetar ("boil"), 2) butiran halus, 3) kilap lembut di tepi bulat.
export const FilterClay: React.FC<Props> = ({id, seed, goyang = 7}) => (
  <filter id={id} x="-5%" y="-5%" width="110%" height="110%" colorInterpolationFilters="sRGB">
    <feTurbulence type="fractalNoise" baseFrequency="0.012 0.018" numOctaves={2} seed={seed} result="warp" />
    <feDisplacementMap in="SourceGraphic" in2="warp" scale={goyang} xChannelSelector="R" yChannelSelector="G" result="goyah" />

    <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves={2} seed={11} result="noise" />
    <feColorMatrix in="noise" type="saturate" values="0" result="abu" />
    <feComposite in="abu" in2="goyah" operator="in" result="butir" />
    <feBlend in="butir" in2="goyah" mode="soft-light" result="bertekstur" />

    <feGaussianBlur in="goyah" stdDeviation={4} result="lembut" />
    <feSpecularLighting in="lembut" surfaceScale={7} specularConstant={0.7} specularExponent={20} lightingColor="#ffffff" result="kilap">
      <fePointLight x={300} y={-200} z={400} />
    </feSpecularLighting>
    <feComposite in="kilap" in2="goyah" operator="in" result="kilapDalam" />
    <feComposite in="bertekstur" in2="kilapDalam" operator="arithmetic" k1={0} k2={1} k3={0.55} k4={0} />
  </filter>
);
