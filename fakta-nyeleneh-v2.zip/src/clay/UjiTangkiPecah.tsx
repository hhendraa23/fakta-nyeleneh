import React from "react";
import {AbsoluteFill, Easing, interpolate} from "remotion";
import {FilterClay} from "./FilterClay";
import {useStopMotion} from "./useStopMotion";
import {tema} from "../styles/tema";

const TANAH = 1250; // garis tanah (px dari atas)
const FRAME_PECAH = 60;

const jepit = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
const halus = {...jepit, easing: Easing.out(Easing.cubic)} as const;

// Tangki utuh (digambar sekali, lalu dipotong dua saat pecah).
const Tangki: React.FC = () => (
  <g>
    <rect x={120} y={560} width={360} height={690} rx={50} fill="#8fa39a" />
    <rect x={120} y={720} width={360} height={36} fill="#76897f" />
    <rect x={120} y={1020} width={360} height={36} fill="#76897f" />
    {[150, 210, 270, 330, 390, 450].map((x) => (
      <React.Fragment key={x}>
        <circle cx={x} cy={738} r={7} fill="#c5d3cc" />
        <circle cx={x} cy={1038} r={7} fill="#c5d3cc" />
      </React.Fragment>
    ))}
    <text x={300} y={920} textAnchor="middle" fontSize={64} fontWeight={900} fontFamily={tema.font} fill="#3b1f0e">
      MOLASE
    </text>
  </g>
);

export const UjiTangkiPecah: React.FC = () => {
  const f = useStopMotion(3);
  const seed = ((f / 3) % 6) + 1;
  const sudahPecah = f >= FRAME_PECAH;

  // Tangki bergetar sebelum pecah, retakan menjalar
  const getarSkala = interpolate(f, [0, FRAME_PECAH - 2], [1, 10], halus);
  const getarX = sudahPecah ? 0 : Math.sin(f * 1.9) * getarSkala * 0.6;
  const retak = interpolate(f, [20, FRAME_PECAH - 2], [0, 1], halus);
  const pecah = interpolate(f, [FRAME_PECAH, 105], [0, 1], halus);

  // Kamera berguncang sebentar saat tangki pecah
  const guncang = sudahPecah ? interpolate(f, [FRAME_PECAH, 100], [22, 0], jepit) : 0;
  const gx = Math.sin(f * 5.3) * guncang;
  const gy = Math.cos(f * 4.1) * guncang;

  // Gelombang molase
  const awal = 300;
  const depan = interpolate(f, [FRAME_PECAH, 160], [awal, 1220], {...jepit, easing: Easing.out(Easing.quad)});
  const tinggi = interpolate(f, [FRAME_PECAH, 100, 180], [160, 430, 300], jepit);

  const bangunGelombang = (): string => {
    const panjang = Math.max(depan - awal, 1);
    let d = `M ${awal} ${TANAH}`;
    for (let x = awal; x <= depan; x += 20) {
      const t = (x - awal) / panjang;
      const h = tinggi * (0.35 + 0.65 * Math.pow(t, 1.5)) * (1 + 0.06 * Math.sin(x / 40 + f / 4));
      d += ` L ${x} ${TANAH - h}`;
    }
    d += ` Q ${depan + 90} ${TANAH - tinggi} ${depan + 70} ${TANAH - tinggi * 0.4}`;
    d += ` Q ${depan + 65} ${TANAH - 20} ${depan + 30} ${TANAH} Z`;
    return d;
  };

  const gedung = [
    {x: 580, w: 170, h: 430, warna: "#d9825b"},
    {x: 780, w: 150, h: 570, warna: "#e9b44c"},
    {x: 950, w: 130, h: 380, warna: "#5fa8a0"},
  ];

  return (
    <AbsoluteFill style={{backgroundColor: "#cfe3ee"}}>
      <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: "absolute", left: 0, top: 0}}>
        <defs>
          <FilterClay id="clay" seed={seed} />
          <clipPath id="kiri">
            <rect x={0} y={0} width={300} height={1920} />
          </clipPath>
          <clipPath id="kanan">
            <rect x={300} y={0} width={780} height={1920} />
          </clipPath>
        </defs>

        <g filter="url(#clay)" transform={`translate(${gx} ${gy})`}>
          {/* tanah */}
          <rect x={-50} y={TANAH} width={1180} height={700} fill="#8a7766" />
          <rect x={-50} y={TANAH} width={1180} height={26} fill="#f2f2ee" />

          {/* gedung: miring saat gelombang lewat */}
          {gedung.map((g, i) => {
            const miring = sudahPecah ? interpolate(depan, [g.x - 60, g.x + 140], [0, 16 + i * 3], jepit) : 0;
            return (
              <g key={i} transform={`rotate(${miring} ${g.x + g.w / 2} ${TANAH})`}>
                <rect x={g.x} y={TANAH - g.h} width={g.w} height={g.h} rx={24} fill={g.warna} />
                {Array.from({length: Math.floor(g.h / 120)}).map((_, r) => (
                  <React.Fragment key={r}>
                    <rect x={g.x + 22} y={TANAH - g.h + 30 + r * 110} width={34} height={46} rx={10} fill="#fff3d6" />
                    <rect x={g.x + g.w - 56} y={TANAH - g.h + 30 + r * 110} width={34} height={46} rx={10} fill="#fff3d6" />
                  </React.Fragment>
                ))}
              </g>
            );
          })}

          {/* tangki */}
          {!sudahPecah ? (
            <g transform={`translate(${getarX} 0)`}>
              <Tangki />
              <path
                d="M300 600 L270 700 L330 790 L280 900 L335 1000 L285 1100 L320 1210"
                fill="none"
                stroke="#3b1f0e"
                strokeWidth={10}
                strokeLinecap="round"
                strokeLinejoin="round"
                pathLength={1}
                strokeDasharray={1}
                strokeDashoffset={1 - retak}
              />
            </g>
          ) : (
            <>
              <g transform={`translate(${-pecah * 140} 0) rotate(${-pecah * 25} 120 ${TANAH})`}>
                <g clipPath="url(#kiri)">
                  <Tangki />
                </g>
              </g>
              <g transform={`translate(${pecah * 120} 0) rotate(${pecah * 35} 480 ${TANAH})`}>
                <g clipPath="url(#kanan)">
                  <Tangki />
                </g>
              </g>
            </>
          )}

          {/* gelombang molase */}
          {sudahPecah ? <path d={bangunGelombang()} fill="#5a2d0c" /> : null}
        </g>
      </svg>

      <div
        style={{
          position: "absolute",
          top: 190,
          width: "100%",
          textAlign: "center",
          fontFamily: tema.font,
          fontSize: 64,
          fontWeight: 900,
          color: "#3b1f0e",
        }}
      >
        BOSTON, 15 JANUARI 1919
      </div>
    </AbsoluteFill>
  );
};
