import {useCurrentFrame} from "remotion";

// Membekukan frame agar gerakan terlihat patah-patah seperti stop-motion.
// langkah = 3 berarti gambar baru tiap 3 frame (10 gambar per detik pada 30 fps).
export const useStopMotion = (langkah = 3): number => {
  const frame = useCurrentFrame();
  return Math.floor(frame / langkah) * langkah;
};
