# FAKTA NYELENEH

Proyek YouTube Shorts (1080x1920, 30 fps) dengan Remotion. Semua konten ada di `data/fakta.json`.

## Menjalankan (Codespaces atau Linux)
1. `bash setup-linux.sh`  (sekali saja)
2. `npm install`
3. `npm run dev`     -> pratinjau di browser
4. `npm run render`  -> hasil di `out/fakta.mp4`

## Render lewat GitHub Actions
Tab Actions -> "Render video" -> Run workflow. Setelah selesai, unduh MP4 dari bagian Artifacts.

## Mengubah konten
Edit `data/fakta.json`. Total durasi harus di bawah 60 detik.
Musik opsional: taruh file di `public/musik/` lalu isi `"musik": "musik/namafile.mp3"`.

## Adegan uji gaya claymation
- `npm run uji:foto`  -> satu gambar (cepat) di `out/uji-clay.png`
- `npm run uji:video` -> video 6 detik di `out/uji-clay.mp4`

## Render cepat (disarankan)
- `npm run uji:cepat` -> merender 10 fps lalu digandakan ke 30 fps, hasil `out/uji-clay.mp4`

## Episode Banjir Molase Boston 1919
- Data adegan dan teks: `data/banjir-molase.json` (durasi tiap adegan, teks, zoom).
- `npm run ep:foto`  -> satu gambar per adegan di `out/ep/` (periksa tampilan)
- `npm run ep:cepat` -> render episode penuh, hasil `out/banjir-molase.mp4`
- Render tanpa menjaga HP tetap menyala: tab Actions -> "Render episode" -> Run workflow.
- Narasi: taruh MP3 di `public/narasi/` lalu isi `"audio": "narasi/namafile.mp3"` di JSON.
