#!/usr/bin/env bash
# Membuat satu gambar per adegan (di 60% durasinya) untuk memeriksa tampilan episode.
set -e
mkdir -p out/ep
FRAMES=$(node -e '
const d = require("./data/banjir-molase.json");
let t = 0; const o = [];
d.adegan.forEach((a) => { o.push(Math.round((t + a.detik * 0.6) * 30)); t += a.detik; });
console.log(o.join(" "));
')
n=1
for f in $FRAMES; do
  nama=$(printf "out/ep/adegan-%02d.png" $n)
  npx remotion still src/index.ts BanjirMolase "$nama" --frame=$f
  n=$((n+1))
done
echo "Selesai: buka folder out/ep"
