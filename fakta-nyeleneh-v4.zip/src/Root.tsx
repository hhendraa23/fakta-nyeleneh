import React from "react";
import {Composition} from "remotion";
import {FaktaVideo} from "./FaktaVideo";
import {hitungDurasiFrame} from "./durasi";
import {UjiTangkiPecah} from "./clay/UjiTangkiPecah";
import {Episode} from "./clay/Episode";
import {Adegan, totalDetik} from "./clay/episode";
import dataEpisode from "../data/banjir-molase.json";
import {FPS, LEBAR, TINGGI} from "./styles/tema";

const DETIK_EPISODE = totalDetik(dataEpisode.adegan as unknown as Adegan[]);
if (DETIK_EPISODE > 60) {
  console.warn(`Episode ${DETIK_EPISODE} detik melebihi 60 detik.`);
}

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="FaktaNyeleneh"
        component={FaktaVideo}
        durationInFrames={hitungDurasiFrame()}
        fps={FPS}
        width={LEBAR}
        height={TINGGI}
      />
      <Composition
        id="UjiClay"
        component={UjiTangkiPecah}
        durationInFrames={180}
        fps={FPS}
        width={LEBAR}
        height={TINGGI}
      />
      <Composition
        id="BanjirMolase"
        component={Episode}
        durationInFrames={Math.round(DETIK_EPISODE * FPS)}
        fps={FPS}
        width={LEBAR}
        height={TINGGI}
      />
      {/* Versi 10 fps untuk render cepat */}
      <Composition
        id="BanjirMolase10"
        component={Episode}
        durationInFrames={Math.round(DETIK_EPISODE * 10)}
        fps={10}
        width={LEBAR}
        height={TINGGI}
      />
      {/* Versi 10 fps: tampilannya sama, tetapi render jauh lebih cepat */}
      <Composition
        id="UjiClay10"
        component={UjiTangkiPecah}
        durationInFrames={60}
        fps={10}
        width={LEBAR}
        height={TINGGI}
      />
    </>
  );
};
