// Adegan "tangki molase pecah" dalam gaya claymation.
// File ini murni fungsi (tanpa React/Remotion) dan menghasilkan teks SVG.
// Satuan waktu: frame animasi pada 30 fps (0 sampai 210).

const TANAH = 1400; // garis tanah
const FRAME_PECAH = 60;
const FONT = "Arial Black, Impact, DejaVu Sans, sans-serif";

const r = (x: number): number => Math.round(x * 10) / 10;
const jepit = (x: number, a: number, b: number): number => Math.min(b, Math.max(a, x));
const linear = (t: number): number => t;
const keluarKubik = (t: number): number => 1 - Math.pow(1 - t, 3);
const keluarKuadrat = (t: number): number => 1 - (1 - t) * (1 - t);

const peta = (
  x: number, x0: number, x1: number, y0: number, y1: number,
  ease: (t: number) => number = linear
): number => {
  const t = jepit((x - x0) / (x1 - x0), 0, 1);
  return y0 + (y1 - y0) * ease(t);
};

// ---------- Filter tanah liat ----------
const filterPenuh = (id: string, seed: number): string => `
<filter id="${id}" x="-12%" y="-12%" width="124%" height="124%" color-interpolation-filters="sRGB">
  <feTurbulence type="fractalNoise" baseFrequency="0.012 0.018" numOctaves="2" seed="${seed}" result="warp"/>
  <feDisplacementMap in="SourceGraphic" in2="warp" scale="10" xChannelSelector="R" yChannelSelector="G" result="goyah"/>
  <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="2" seed="11" result="n1"/>
  <feColorMatrix in="n1" type="saturate" values="0" result="g1"/>
  <feComposite in="g1" in2="goyah" operator="in" result="butir"/>
  <feBlend in="butir" in2="goyah" mode="soft-light" result="t1"/>
  <feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves="3" seed="5" result="n2"/>
  <feColorMatrix in="n2" type="saturate" values="0" result="g2"/>
  <feComposite in="g2" in2="goyah" operator="in" result="bercak"/>
  <feBlend in="bercak" in2="t1" mode="soft-light" result="tex"/>
  <feGaussianBlur in="goyah" stdDeviation="5" result="lembut"/>
  <feDiffuseLighting in="lembut" surfaceScale="9" diffuseConstant="1.3" lighting-color="#ffffff" result="bayang">
    <feDistantLight azimuth="225" elevation="50"/>
  </feDiffuseLighting>
  <feComposite in="bayang" in2="goyah" operator="in" result="bayangIn"/>
  <feBlend in="bayangIn" in2="tex" mode="multiply" result="teduh"/>
  <feSpecularLighting in="lembut" surfaceScale="9" specularConstant="0.5" specularExponent="22" lighting-color="#ffffff" result="kilap">
    <feDistantLight azimuth="225" elevation="50"/>
  </feSpecularLighting>
  <feComposite in="kilap" in2="goyah" operator="in" result="kilapIn"/>
  <feComposite in="teduh" in2="kilapIn" operator="arithmetic" k1="0" k2="1" k3="0.5" k4="0" result="isi"/>
  <feMorphology in="goyah" operator="dilate" radius="3" result="tebal"/>
  <feFlood flood-color="#2b1708" flood-opacity="0.6" result="tinta"/>
  <feComposite in="tinta" in2="tebal" operator="in" result="garis"/>
  <feMerge><feMergeNode in="garis"/><feMergeNode in="isi"/></feMerge>
</filter>`;

// Versi ringan (tanpa pencahayaan) untuk benda besar atau latar.
const filterRingan = (id: string, seed: number): string => `
<filter id="${id}" x="-5%" y="-5%" width="110%" height="110%" color-interpolation-filters="sRGB">
  <feTurbulence type="fractalNoise" baseFrequency="0.012 0.018" numOctaves="2" seed="${seed}" result="warp"/>
  <feDisplacementMap in="SourceGraphic" in2="warp" scale="8" xChannelSelector="R" yChannelSelector="G" result="goyah"/>
  <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="2" seed="11" result="n1"/>
  <feColorMatrix in="n1" type="saturate" values="0" result="g1"/>
  <feComposite in="g1" in2="goyah" operator="in" result="butir"/>
  <feBlend in="butir" in2="goyah" mode="soft-light"/>
</filter>`;

const pakai = (id: string, isi: string): string => `<g filter="url(#${id})">${isi}</g>`;

// ---------- Benda-benda ----------
const jendela = (x: number, atas: number, w: number, h: number): string => {
  let s = "";
  const baris = Math.floor((h - 90) / 110);
  for (let i = 0; i < baris; i++) {
    const y = atas + 70 + i * 110;
    s += `<rect x="${x + 24}" y="${y}" width="36" height="48" rx="11" fill="#fff3d6"/>`;
    s += `<rect x="${x + w - 60}" y="${y}" width="36" height="48" rx="11" fill="#fff3d6"/>`;
  }
  return s;
};

const awan = (x: number, y: number, s: number): string =>
  `<g opacity="0.92">` +
  `<circle cx="${r(x)}" cy="${y}" r="${r(46 * s)}" fill="#ffffff"/>` +
  `<circle cx="${r(x + 55 * s)}" cy="${r(y - 18 * s)}" r="${r(58 * s)}" fill="#ffffff"/>` +
  `<circle cx="${r(x + 112 * s)}" cy="${y}" r="${r(44 * s)}" fill="#ffffff"/>` +
  `<rect x="${r(x - 40 * s)}" y="${r(y + 4 * s)}" width="${r(196 * s)}" height="${r(40 * s)}" rx="${r(20 * s)}" fill="#ffffff"/>` +
  `</g>`;

const TANGKI = {x: 60, y: 800, w: 460, h: 600};
const PUSAT_TANGKI = TANGKI.x + TANGKI.w / 2; // 290

const isiTangki = (): string => {
  const {x, y, w, h} = TANGKI;
  let s = `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="64" fill="#8fa39a"/>`;
  s += `<rect x="${x}" y="${y + 150}" width="${w}" height="40" fill="#76897f"/>`;
  s += `<rect x="${x}" y="${y + 420}" width="${w}" height="40" fill="#76897f"/>`;
  for (let xx = x + 36; xx < x + w; xx += 62) {
    s += `<circle cx="${xx}" cy="${y + 170}" r="8" fill="#c5d3cc"/>`;
    s += `<circle cx="${xx}" cy="${y + 440}" r="8" fill="#c5d3cc"/>`;
  }
  s += `<rect x="${x - 8}" y="${y - 16}" width="${w + 16}" height="34" rx="17" fill="#f4f6f8"/>`;
  s += `<text x="${PUSAT_TANGKI}" y="${y + 330}" text-anchor="middle" font-size="76" font-weight="900" font-family="${FONT}" fill="#3b1f0e">MOLASE</text>`;
  return s;
};

type Gedung = {x: number; w: number; h: number; warna: string};
const GEDUNG: Gedung[] = [
  {x: 560, w: 150, h: 520, warna: "#d9825b"},
  {x: 730, w: 170, h: 700, warna: "#e9b44c"},
  {x: 920, w: 140, h: 460, warna: "#5fa8a0"},
];
const GEDUNG_BELAKANG: Gedung[] = [
  {x: 600, w: 120, h: 780, warna: "#c9a0b4"},
  {x: 850, w: 120, h: 610, warna: "#9fb0d8"},
];

const badanGedung = (g: Gedung): string => {
  const atas = TANAH - g.h;
  return (
    `<rect x="${g.x}" y="${atas}" width="${g.w}" height="${g.h}" rx="26" fill="${g.warna}"/>` +
    `<rect x="${g.x - 6}" y="${atas - 14}" width="${g.w + 12}" height="32" rx="16" fill="#f4f6f8"/>` +
    jendela(g.x, atas, g.w, g.h)
  );
};

// ---------- Gelombang molase ----------
const AWAL = PUSAT_TANGKI;

const tinggiDi = (x: number, depan: number, H: number, f: number): number => {
  const panjang = Math.max(depan - AWAL, 1);
  const t = jepit((x - AWAL) / panjang, 0, 1);
  const landai = keluarKuadrat(jepit((x - AWAL) / 220, 0, 1));
  return H * landai * (0.45 + 0.55 * Math.pow(t, 2.2)) * (1 + 0.07 * Math.sin(x / 45 + f / 3.2) + 0.05 * Math.sin(x / 90 - f / 5));
};

const gelombang = (f: number, depan: number, H: number): string => {
  let d = `M ${AWAL} ${TANAH}`;
  let garis = "";
  for (let x = AWAL; x <= depan - 10; x += 24) {
    const y = r(TANAH - tinggiDi(x, depan, H, f));
    d += ` L ${r(x)} ${y}`;
    garis += `${garis === "" ? "M" : "L"} ${r(x)} ${y} `;
  }
  d += ` L ${r(depan)} ${r(TANAH - H)}`;
  d += ` Q ${r(depan + 90)} ${r(TANAH - H * 1.08)} ${r(depan + 100)} ${r(TANAH - H * 0.78)}`;
  d += ` Q ${r(depan + 78)} ${r(TANAH - H * 0.66)} ${r(depan + 38)} ${r(TANAH - H * 0.6)}`;
  d += ` Q ${r(depan + 90)} ${r(TANAH - H * 0.32)} ${r(depan + 96)} ${r(TANAH)} Z`;

  let s = `<path d="${d}" fill="#5a2d0c"/>`;
  if (garis !== "") {
    s += `<path d="${garis}" fill="none" stroke="#9a5a2a" stroke-width="12" stroke-linecap="round" stroke-linejoin="round" opacity="0.7"/>`;
  }
  // gelembung dan kilau di permukaan
  for (let k = 0; k < 6; k++) {
    const x = depan - 30 - k * 70;
    if (x <= AWAL + 20) continue;
    const y = TANAH - tinggiDi(x, depan, H, f) + 34 + (k % 2) * 26;
    s += `<circle cx="${r(x)}" cy="${r(y)}" r="${11 + (k % 3) * 5}" fill="#8a4a1e" opacity="0.75"/>`;
  }
  // tetesan terlempar di depan puncak
  for (let k = 0; k < 4; k++) {
    s += `<circle cx="${r(depan + 130 + k * 48)}" cy="${r(TANAH - H * (0.98 - k * 0.14))}" r="${15 - k * 2}" fill="#5a2d0c"/>`;
  }
  return s;
};

// ---------- Adegan lengkap ----------
export const buatAdegan = (f: number, denyut: number = f / 3): string => {
  const seed = (Math.floor(denyut) % 6) + 1;
  const sudahPecah = f >= FRAME_PECAH;

  const getarSkala = peta(f, 0, FRAME_PECAH - 2, 1, 10, keluarKubik);
  const getarX = sudahPecah ? 0 : Math.sin(f * 1.9) * getarSkala * 0.6;
  const retak = peta(f, 20, FRAME_PECAH - 2, 0, 1, keluarKubik);
  const pecah = peta(f, FRAME_PECAH, 110, 0, 1, keluarKubik);

  const guncang = sudahPecah ? peta(f, FRAME_PECAH, 105, 24, 0) : 0;
  const gx = Math.sin(f * 5.3) * guncang;
  const gy = Math.cos(f * 4.1) * guncang;

  const depan = peta(f, FRAME_PECAH, 185, AWAL, 1300, keluarKuadrat);
  const H = f < 100 ? peta(f, FRAME_PECAH, 100, 150, 560, keluarKubik) : peta(f, 100, 210, 560, 470);

  let s = `<defs>${filterPenuh("c1", seed)}${filterPenuh("c2", ((seed + 1) % 6) + 1)}${filterPenuh("c3", ((seed + 3) % 6) + 1)}${filterRingan("r1", ((seed + 2) % 6) + 1)}` +
    `<clipPath id="kiri"><rect x="0" y="0" width="${PUSAT_TANGKI}" height="1920"/></clipPath>` +
    `<clipPath id="kanan"><rect x="${PUSAT_TANGKI}" y="0" width="900" height="1920"/></clipPath></defs>`;

  s += `<g transform="translate(${r(gx)} ${r(gy)})">`;

  // awan melayang pelan
  s += pakai("r1", awan(120 + f * 0.25, 330, 1.2) + awan(640 + f * 0.18, 470, 0.9));

  // tanah: trotoar dan jalan
  let tanah = `<rect x="-60" y="${TANAH}" width="1200" height="${1920 - TANAH + 60}" fill="#6f6256"/>`;
  tanah += `<rect x="-60" y="${TANAH}" width="1200" height="70" fill="#b9a894"/>`;
  tanah += `<rect x="-60" y="${TANAH}" width="1200" height="20" fill="#f4f6f8"/>`;
  for (let i = 0; i < 6; i++) {
    tanah += `<rect x="${-40 + i * 220}" y="1700" width="130" height="22" rx="11" fill="#f2c14e"/>`;
  }
  s += pakai("r1", tanah);

  // gedung latar belakang
  s += pakai("r1", GEDUNG_BELAKANG.map((g) => badanGedung(g)).join(""));

  // gedung depan: terdorong dan miring saat gelombang tiba
  GEDUNG.forEach((g, i) => {
    const p = sudahPecah ? peta(depan, g.x - 90, g.x + 90, 0, 1, keluarKubik) : 0;
    const sudut = p * (26 + i * 5);
    const dx = p * (40 + i * 25);
    const dy = p * 45;
    const cx = g.x + g.w / 2;
    s += pakai(`c${(i % 3) + 1}`, `<g transform="translate(${r(dx)} ${r(dy)}) rotate(${r(sudut)} ${cx} ${TANAH})">${badanGedung(g)}</g>`);
  });

  // tangki
  if (!sudahPecah) {
    const retakPath = `<path d="M290 830 L255 930 L320 1020 L265 1120 L325 1220 L270 1320 L300 1392" fill="none" stroke="#3b1f0e" stroke-width="11" stroke-linecap="round" stroke-linejoin="round" pathLength="1" stroke-dasharray="1" stroke-dashoffset="${r(1 - retak)}"/>`;
    s += pakai("c1", `<g transform="translate(${r(getarX)} 0)">${isiTangki()}${retakPath}</g>`);
  } else {
    const cL = (TANGKI.x + PUSAT_TANGKI) / 2;
    const cR = (PUSAT_TANGKI + TANGKI.x + TANGKI.w) / 2;
    const merosot = (c: number, arah: number): string =>
      `translate(${r(arah * pecah * 38)} 0) translate(${c} ${TANAH}) rotate(${r(arah * pecah * 9)}) scale(${r(1 + 0.12 * pecah)} ${r(1 - 0.62 * pecah)}) translate(${-c} ${-TANAH})`;
    s += pakai("c1", `<g transform="${merosot(cL, -1)}"><g clip-path="url(#kiri)">${isiTangki()}</g></g>`);
    s += pakai("c2", `<g transform="${merosot(cR, 1)}"><g clip-path="url(#kanan)">${isiTangki()}</g></g>`);
    s += pakai("c3", gelombang(f, depan, H));
  }

  s += `</g>`;
  return s;
};
