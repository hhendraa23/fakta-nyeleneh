// Logika waktu episode (murni, tanpa React) agar mudah diuji.
export type Adegan = {
  detik: number; // lama adegan pada video
  dari: number; // frame animasi awal (0-210)
  ke: number; // frame animasi akhir
  judul: string; // teks besar di atas
  teks: string; // kalimat narasi (subjudul)
  zoomDari?: number;
  zoomKe?: number;
  fokusX?: number; // titik pusat zoom (px)
  fokusY?: number;
  redup?: boolean; // adegan tenang: layar digelapkan sedikit
  gaya?: "adegan" | "judul";
};

export const jepit = (x: number, a: number, b: number): number => Math.min(b, Math.max(a, x));

export const totalDetik = (daftar: Adegan[]): number => daftar.reduce((j, a) => j + a.detik, 0);

export const cariAdegan = (
  daftar: Adegan[],
  t: number
): {indeks: number; a: Adegan; p: number; lokal: number} => {
  let awal = 0;
  for (let i = 0; i < daftar.length; i++) {
    const a = daftar[i];
    if (t < awal + a.detik || i === daftar.length - 1) {
      return {indeks: i, a, p: jepit((t - awal) / a.detik, 0, 1), lokal: Math.max(0, t - awal)};
    }
    awal += a.detik;
  }
  return {indeks: 0, a: daftar[0], p: 0, lokal: 0};
};

export const frameAnimasi = (a: Adegan, p: number): number => Math.round(a.dari + p * (a.ke - a.dari));
