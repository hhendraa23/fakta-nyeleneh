import React from "react";
import {AbsoluteFill, Audio, interpolate, staticFile, useCurrentFrame, useVideoConfig} from "remotion";
import data from "../../data/banjir-molase.json";
import {buatAdegan} from "./adegan";
import {Adegan, cariAdegan, frameAnimasi} from "./episode";
import {tema} from "../styles/tema";

const ADEGAN = data.adegan as unknown as Adegan[];

const garisTepi =
  "3px 3px 0 #3b1f0e, -3px 3px 0 #3b1f0e, 3px -3px 0 #3b1f0e, -3px -3px 0 #3b1f0e, 0 8px 18px rgba(0,0,0,0.4)";

export const Episode: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const {a, p, lokal} = cariAdegan(ADEGAN, t);

  // Nomor gambar stop-motion (10 gambar per detik), dipakai untuk getaran tepi
  const denyut = Math.floor((frame * (30 / fps)) / 3);
  const fAnim = frameAnimasi(a, p);

  const zDari = a.zoomDari ?? 1;
  const zKe = a.zoomKe ?? 1;
  const zoom = zDari + (zKe - zDari) * p;
  const opasitas = interpolate(lokal, [0, 0.3], [0, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});

  const audio = data.audio ? <Audio src={staticFile(data.audio)} /> : null;

  if (a.gaya === "judul") {
    return (
      <AbsoluteFill
        style={{
          background: "linear-gradient(#7b2cbf, #240046)",
          justifyContent: "center",
          alignItems: "center",
          padding: "0 80px 300px 80px",
        }}
      >
        <div
          style={{
            opacity: opasitas,
            fontFamily: tema.font,
            fontSize: 118,
            fontWeight: 900,
            lineHeight: 1.15,
            textAlign: "center",
            color: tema.aksen,
            textShadow: garisTepi,
          }}
        >
          {a.judul}
        </div>
        <div style={{marginTop: 50, opacity: opasitas, fontFamily: tema.font, fontSize: 60, fontWeight: 900, color: "#ffffff", letterSpacing: 6}}>
          FAKTA NYELENEH
        </div>
        {audio}
      </AbsoluteFill>
    );
  }

  return (
    <AbsoluteFill style={{background: "linear-gradient(#a8cbe0, #dcebf3 60%)"}}>
      <div
        style={{
          position: "absolute",
          inset: 0,
          transform: `scale(${zoom})`,
          transformOrigin: `${a.fokusX ?? 540}px ${a.fokusY ?? 1000}px`,
        }}
      >
        <svg
          width={1080}
          height={1920}
          viewBox="0 0 1080 1920"
          style={{position: "absolute", left: 0, top: 0}}
          dangerouslySetInnerHTML={{__html: buatAdegan(fAnim, denyut)}}
        />
      </div>

      {a.redup ? <AbsoluteFill style={{backgroundColor: "rgba(25,12,5,0.38)"}} /> : null}

      <div
        style={{
          position: "absolute",
          top: 230,
          width: "100%",
          padding: "0 70px",
          boxSizing: "border-box",
          textAlign: "center",
          opacity: opasitas,
          fontFamily: tema.font,
          fontSize: 78,
          fontWeight: 900,
          lineHeight: 1.12,
          color: "#ffffff",
          textShadow: garisTepi,
        }}
      >
        {a.judul}
      </div>

      <div
        style={{
          position: "absolute",
          bottom: 400,
          left: 60,
          right: 60,
          padding: "26px 34px",
          boxSizing: "border-box",
          borderRadius: 36,
          backgroundColor: "rgba(30,15,5,0.74)",
          opacity: opasitas,
          fontFamily: "Arial, Helvetica, sans-serif",
          fontSize: 46,
          fontWeight: 700,
          lineHeight: 1.3,
          textAlign: "center",
          color: "#fff7e6",
        }}
      >
        {a.teks}
      </div>
      {audio}
    </AbsoluteFill>
  );
};
