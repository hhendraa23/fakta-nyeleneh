#!/usr/bin/env bash
# Satu gambar per beat (di 70% durasinya) untuk memeriksa tampilan episode Pompeii.
set -e
mkdir -p out/sandi
FRAMES=$(node -e '
const d = require("./data/pompeii.json");
let t = 0; const o = [];
d.beats.forEach((b) => { o.push(Math.round((t + b.dur * 0.7) * 30)); t += b.dur; });
console.log(o.join(" "));
')
n=1
for f in $FRAMES; do
  npx remotion still src/index.ts SandiPompeii "$(printf "out/sandi/beat-%02d.png" $n)" --frame=$f
  n=$((n+1))
done
echo "Selesai: buka folder out/sandi"
