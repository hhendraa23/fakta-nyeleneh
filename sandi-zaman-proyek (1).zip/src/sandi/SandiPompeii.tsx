import React from "react";
import {AbsoluteFill, Audio, Series, staticFile} from "remotion";
import data from "../../data/pompeii.json";
import {BeatData, EpisodeData} from "./data";
import {Beat1, Beat2, Beat3, Beat4, Beat5, Beat6, Beat7, BP} from "./beats";
import {FPS} from "./tema";

const EP = data as unknown as EpisodeData;

const PETA_BEAT: Record<BeatData["tipe"], React.FC<BP>> = {
  hook: Beat1,
  surat: Beat2,
  kalender: Beat3,
  "garis-waktu": Beat4,
  potret: Beat5,
  dna: Beat6,
  tutup: Beat7,
};

export const SandiPompeii: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: "#000"}}>
    <Series>
      {EP.beats.map((b) => {
        const Komponen = PETA_BEAT[b.tipe];
        const frames = Math.round(b.dur * FPS);
        return (
          <Series.Sequence key={b.id} durationInFrames={frames}>
            <Komponen frames={frames} foto={b.foto || undefined} kredit={EP.kredit} />
          </Series.Sequence>
        );
      })}
    </Series>
    {/* Tanpa subtitle terbakar (standar Sandi Zaman): subtitle lewat berkas SRT terpisah */}
    {EP.audio ? <Audio src={staticFile(EP.audio)} /> : null}
  </AbsoluteFill>
);
