// Tema infografis Sandi Zaman
export const S = {
  navy: "#202440",
  krem: "#faf3e0",
  oranye: "#f48c42",
  kuning: "#ffd04d",
  teal: "#3caaa0",
  merah: "#b3202a",
  laut: "#7fc6d9",
  darat: "#eee5c8",
  salmon: "#ffaa96",
  mint: "#b8e0d2",
  font: '"DejaVu Sans", Arial, Helvetica, sans-serif',
  fontSerif: '"DejaVu Serif", Georgia, "Times New Roman", serif',
};

export type Label = "FAKTA" | "DUGAAN ILMIAH" | "BELUM TERJAWAB";

export const warnaLabel: Record<Label, string> = {
  FAKTA: S.kuning,
  "DUGAAN ILMIAH": S.salmon,
  "BELUM TERJAWAB": S.mint,
};

export const FPS = 30;
