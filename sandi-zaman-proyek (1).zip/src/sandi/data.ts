// Tipe dan fungsi waktu (murni, tanpa React) untuk episode Sandi Zaman.
export type BeatData = {
  id: string;
  dur: number; // detik
  tipe: "hook" | "surat" | "kalender" | "garis-waktu" | "potret" | "dna" | "tutup";
  tenang?: boolean; // mode tenang untuk beat tentang korban
  narasi: string;
  foto?: string; // jalur di public/, kosong = penampung
};

export type EpisodeData = {
  judul: string;
  kredit: string;
  audio: string;
  beats: BeatData[];
};

export const totalDetik = (beats: BeatData[]): number => beats.reduce((j, b) => j + b.dur, 0);

export const mulaiBeat = (beats: BeatData[], i: number): number =>
  beats.slice(0, i).reduce((j, b) => j + b.dur, 0);
