import React from "react";
import {
  Kamera, Kredit, KartuAngka, KartuTeks, Kartu, FotoSobek, JudulBaris, LabelPill, LingkaranMerah,
  Peta, PinPeta, Pill, tampil, useMasuk,
} from "./komponen";
import {S} from "./tema";

export type BP = {frames: number; foto?: string; kredit: string};

const Teks: React.FC<{
  x: number; y: number; w?: number; ukuran: number; mulai: number; warna?: string; serif?: boolean; rata?: "left" | "center"; children: React.ReactNode;
}> = ({x, y, w = 960, ukuran, mulai, warna = S.navy, serif, rata = "center", children}) => {
  const p = tampil(useMasuk(mulai));
  return (
    <div
      style={{
        position: "absolute", left: x, top: y, width: w, textAlign: rata,
        fontFamily: serif ? S.fontSerif : S.font, fontWeight: 900, fontSize: ukuran, lineHeight: 1.1,
        color: warna, opacity: p, transform: `translateY(${(1 - p) * 30}px)`,
      }}
    >
      {children}
    </div>
  );
};

const TopPill: React.FC<{teks: string; warna: string}> = ({teks, warna}) => {
  const a = tampil(useMasuk(0));
  return (
    <div style={{position: "absolute", left: 60, top: 150, opacity: a, transform: `translateY(${(1 - a) * -30}px)`}}>
      <Pill teks={teks} warna={warna} ukuran={32} />
    </div>
  );
};

// BEAT 1: pembuka
export const Beat1: React.FC<BP> = ({frames, kredit}) => (
  <Kamera frames={frames} arah={1}>
    <Peta />
    <TopPill teks="MISTERI 1 · TANGGAL LETUSAN" warna={S.oranye} />
    <JudulBaris teks="Kapan Pompeii" top={250} mulai={0.3} />
    <JudulBaris teks="benar-benar" top={365} mulai={0.65} />
    <JudulBaris teks="hancur?" top={480} mulai={1.0} />
    <PinPeta x={500} y={780} teks="Vesuvius" warna={S.oranye} mulai={1.6} />
    <PinPeta x={560} y={900} teks="Pompeii" warna={S.teal} mulai={2.0} />
    <KartuAngka x={230} y={1010} w={620} h={400} label="FAKTA" besar="24" bulan="AGUSTUS 79" sub="Menurut surat Pliny the Younger" mulai={2.8} />
    <Kredit teks={kredit} />
  </Kamera>
);

// BEAT 2: surat Pliny
export const Beat2: React.FC<BP> = ({frames, foto, kredit}) => (
  <Kamera frames={frames} arah={-1}>
    <Peta />
    <TopPill teks="MISTERI 1 · SAKSI TERTULIS" warna={S.oranye} />
    <FotoSobek x={60} y={330} w={440} h={560} rot={-2} src={foto} mulai={0.4} />
    <KartuTeks x={540} y={330} w={480} h={560} label="FAKTA" judul="Surat Pliny the Younger kepada Tacitus" sub="Ditulis puluhan tahun setelah letusan" mulai={1.0} ukuran={46} />
    <KartuTeks x={60} y={960} w={960} h={330} label="FAKTA" judul="Salinan surat tidak seragam" sub="Tidak semua salinan mencantumkan 24 Agustus." mulai={3.6} ukuran={58} />
    <Kredit teks={kredit} />
  </Kamera>
);

// BEAT 3: tulisan arang 2018
export const Beat3: React.FC<BP> = ({frames, kredit}) => (
  <Kamera frames={frames} arah={1}>
    <Peta />
    <TopPill teks="MISTERI 1 · TULISAN ARANG 2018" warna={S.oranye} />
    <KartuTeks x={60} y={300} w={960} h={600} label="FAKTA" judul="" mulai={0.2} />
    <Teks x={60} y={430} ukuran={118} serif mulai={0.8}>XVI K NOV</Teks>
    <Teks x={60} y={580} ukuran={80} mulai={1.8} warna={S.oranye}>▼</Teks>
    <Teks x={60} y={690} ukuran={104} mulai={2.2}>17 OKTOBER</Teks>
    <Teks x={90} y={845} w={900} ukuran={28} mulai={2.6} warna="#5a5048">Casa del Giardino, Pompeii · ditemukan 2018</Teks>
    <LingkaranMerah cx={540} cy={742} rx={440} ry={80} mulai={3.4} />
    <KartuTeks x={60} y={970} w={960} h={290} label="DUGAAN ILMIAH" judul="Letusan lebih lambat dari 24 Agustus?" mulai={4.6} ukuran={52} />
    <Kredit teks={kredit} />
  </Kamera>
);

// BEAT 4: pemeriksaan ulang 2024
export const Beat4: React.FC<BP> = ({frames, kredit}) => {
  const garis = tampil(useMasuk(0.8, 30));
  return (
    <Kamera frames={frames} arah={-1}>
      <Peta />
      <TopPill teks="MISTERI 1 · PEMERIKSAAN ULANG" warna={S.oranye} />
      <div style={{position: "absolute", left: 60, top: 300, width: 960, height: 400}}>
        <Kartu style={{width: "100%", height: "100%"}}>
          <LabelPill label="FAKTA" />
        </Kartu>
      </div>
      <div style={{position: "absolute", left: 200, top: 520, width: 680 * garis, height: 10, background: S.navy, borderRadius: 5}} />
      <Teks x={60} y={430} ukuran={92} w={400} mulai={0.4}>2018</Teks>
      <Teks x={620} y={430} ukuran={92} w={400} mulai={1.6}>2024</Teks>
      <Teks x={60} y={580} ukuran={28} w={400} mulai={0.8} warna="#5a5048">Tulisan arang ditemukan</Teks>
      <Teks x={600} y={580} ukuran={28} w={440} mulai={2.0} warna="#5a5048">Taman Arkeologi memeriksa ulang</Teks>
      <KartuTeks x={60} y={780} w={960} h={380} label="DUGAAN ILMIAH" judul="Belum cukup untuk menyingkirkan 24 Agustus" mulai={3.4} ukuran={60} />
      <KartuTeks x={60} y={1230} w={960} h={190} label="BELUM TERJAWAB" judul="Tanggal pasti: masih diperdebatkan" mulai={5.4} ukuran={40} />
      <Kredit teks={kredit} />
    </Kamera>
  );
};

// BEAT 5 (mode tenang): Fiorelli
export const Beat5: React.FC<BP> = ({frames, foto, kredit}) => (
  <Kamera frames={frames} arah={1}>
    <Peta redup />
    <TopPill teks="MISTERI 2 · IDENTITAS KORBAN" warna={S.mint} />
    <FotoSobek x={60} y={330} w={420} h={560} rot={0} src={foto} mulai={0.4} />
    <KartuAngka x={520} y={330} w={500} h={560} label="FAKTA" besar="1863" bulan="G. FIORELLI" sub="Plester dituang ke rongga yang ditinggalkan tubuh di dalam abu." mulai={1.0} />
    <Kredit teks={kredit} />
  </Kamera>
);

// BEAT 6 (mode tenang): DNA 14 cetakan
const TITIK_DATA = [0, 2, 5, 8, 11];
export const Beat6: React.FC<BP> = ({frames, kredit}) => {
  const titik = Array.from({length: 14}).map((_, i) => i);
  const aktif = tampil(useMasuk(2.0, 30));
  return (
    <Kamera frames={frames} arah={-1}>
      <Peta redup />
      <TopPill teks="MISTERI 2 · IDENTITAS KORBAN" warna={S.mint} />
      <JudulBaris teks="14 cetakan diteliti" top={250} mulai={0.3} ukuran={84} />
      {titik.map((i) => {
        const col = i % 7;
        const row = Math.floor(i / 7);
        const hidup = TITIK_DATA.indexOf(i) >= 0;
        return (
          <div
            key={i}
            style={{
              position: "absolute", left: 84 + col * 140, top: 460 + row * 140, width: 72, height: 72, borderRadius: 72,
              boxSizing: "border-box", border: `5px solid ${S.navy}`,
              background: hidup && aktif > 0.5 ? S.teal : S.krem,
            }}
          />
        );
      })}
      <Teks x={60} y={750} ukuran={50} mulai={3.4} warna={S.navy}>5 menghasilkan data yang bisa dianalisis</Teks>
      <KartuTeks x={60} y={900} w={960} h={330} label="FAKTA" judul="Sosok yang disangka ibu: pria dewasa" sub="Tidak sekerabat dengan anak yang digendongnya." mulai={5.0} ukuran={54} />
      <KartuTeks x={60} y={1265} w={960} h={235} label="BELUM TERJAWAB" judul="Hubungan sosial mereka: belum diketahui" mulai={8.2} ukuran={38} />
      <Kredit teks={kredit} />
    </Kamera>
  );
};

// BEAT 7 (mode tenang): pertanyaan penutup
export const Beat7: React.FC<BP> = ({frames, kredit}) => (
  <Kamera frames={frames} arah={1}>
    <Peta redup />
    <TopPill teks="MISTERI 2 · IDENTITAS KORBAN" warna={S.mint} />
    <KartuTeks x={60} y={520} w={960} h={560} label="BELUM TERJAWAB" judul="Siapa sebenarnya mereka bagi satu sama lain?" sub="DNA menunjukkan hubungan biologis, bukan hubungan sosial." mulai={0.4} ukuran={74} />
    <Kredit teks={kredit} />
  </Kamera>
);
