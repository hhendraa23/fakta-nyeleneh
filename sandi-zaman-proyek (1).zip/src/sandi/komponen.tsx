import React from "react";
import {AbsoluteFill, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from "remotion";
import {S, Label, warnaLabel} from "./tema";

export const tampil = (x: number): number => Math.min(1, Math.max(0, x));

// Animasi masuk (0 -> 1) yang dimulai pada detik tertentu di dalam beat
export const useMasuk = (detik = 0, damping = 14): number => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: frame - Math.round(detik * fps), fps, config: {damping}});
};

// Gerakan kamera halus (zoom dan geser) sepanjang beat
export const Kamera: React.FC<{frames: number; arah?: number; children: React.ReactNode}> = ({
  frames,
  arah = 1,
  children,
}) => {
  const frame = useCurrentFrame();
  const kunci = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
  const skala = interpolate(frame, [0, frames], [1.0, 1.06], kunci);
  const geser = interpolate(frame, [0, frames], [0, -22 * arah], kunci);
  return (
    <AbsoluteFill style={{transform: `translateY(${geser}px) scale(${skala})`, transformOrigin: "50% 45%"}}>
      {children}
    </AbsoluteFill>
  );
};

// Peta latar ilustrasi (laut di kiri, darat di kanan). Bukan peta akurat.
export const Peta: React.FC<{redup?: boolean}> = ({redup}) => {
  const garis: number[] = [];
  for (let i = 0; i <= 1920; i += 90) garis.push(i);
  const jalan = [
    [420, 330, 1080, 380],
    [420, 590, 1080, 520],
    [420, 850, 1080, 930],
    [420, 1110, 1080, 1060],
    [420, 1370, 1080, 1450],
  ];
  return (
    <AbsoluteFill style={{backgroundColor: S.darat}}>
      <svg
        width={1080}
        height={1920}
        viewBox="0 0 1080 1920"
        style={{position: "absolute", left: 0, top: 0, opacity: redup ? 0.55 : 1}}
      >
        <polygon points="0,0 330,0 380,260 300,520 380,800 330,1100 420,1400 360,1700 420,1920 0,1920" fill={S.laut} />
        {garis.map((v) => (
          <React.Fragment key={v}>
            <line x1={0} y1={v} x2={1080} y2={v} stroke="#e4dabc" strokeWidth={2} />
            <line x1={v} y1={0} x2={v} y2={1920} stroke="#e4dabc" strokeWidth={2} />
          </React.Fragment>
        ))}
        {jalan.map((j, i) => (
          <line key={i} x1={j[0]} y1={j[1]} x2={j[2]} y2={j[3]} stroke="#fcf8ec" strokeWidth={14} strokeLinecap="round" />
        ))}
      </svg>
    </AbsoluteFill>
  );
};

export const Pill: React.FC<{teks: string; warna: string; ukuran?: number}> = ({teks, warna, ukuran = 30}) => (
  <div
    style={{
      display: "inline-block",
      padding: `${Math.round(ukuran * 0.45)}px ${Math.round(ukuran * 0.9)}px`,
      borderRadius: 999,
      background: warna,
      color: S.navy,
      fontFamily: S.font,
      fontWeight: 900,
      fontSize: ukuran,
      border: `4px solid ${S.navy}`,
      boxShadow: `6px 6px 0 ${S.navy}`,
      letterSpacing: 1,
      whiteSpace: "nowrap",
    }}
  >
    {teks}
  </div>
);

export const LabelPill: React.FC<{label: Label; ukuran?: number}> = ({label, ukuran = 26}) => (
  <Pill teks={label} warna={warnaLabel[label]} ukuran={ukuran} />
);

export const Kartu: React.FC<{children?: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <div
    style={{
      background: S.krem,
      border: `5px solid ${S.navy}`,
      borderRadius: 36,
      boxShadow: `10px 10px 0 ${S.navy}`,
      boxSizing: "border-box",
      padding: 28,
      ...style,
    }}
  >
    {children}
  </div>
);

export const JudulBaris: React.FC<{teks: string; top: number; mulai: number; ukuran?: number}> = ({
  teks,
  top,
  mulai,
  ukuran = 100,
}) => {
  const p = tampil(useMasuk(mulai));
  return (
    <div
      style={{
        position: "absolute",
        left: 60,
        top,
        fontFamily: S.font,
        fontWeight: 900,
        fontSize: ukuran,
        color: S.navy,
        opacity: p,
        transform: `translateY(${(1 - p) * 40}px)`,
        whiteSpace: "nowrap",
      }}
    >
      {teks}
    </div>
  );
};

export const PinPeta: React.FC<{x: number; y: number; teks: string; warna: string; mulai: number}> = ({
  x,
  y,
  teks,
  warna,
  mulai,
}) => {
  const p = tampil(useMasuk(mulai));
  return (
    <div style={{position: "absolute", left: x, top: y, opacity: p, transform: `scale(${0.7 + 0.3 * p})`}}>
      <div
        style={{
          position: "absolute",
          left: -18,
          top: -18,
          width: 36,
          height: 36,
          borderRadius: 36,
          background: warna,
          border: `5px solid ${S.navy}`,
          boxSizing: "border-box",
        }}
      />
      <div
        style={{
          position: "absolute",
          left: 30,
          top: -28,
          padding: "8px 20px",
          borderRadius: 14,
          background: S.krem,
          border: `3px solid ${S.navy}`,
          boxShadow: `5px 5px 0 ${S.navy}`,
          fontFamily: S.font,
          fontWeight: 900,
          fontSize: 30,
          color: S.navy,
          whiteSpace: "nowrap",
        }}
      >
        {teks}
      </div>
    </div>
  );
};

// Foto arsip hitam-putih bertepi sobek. Tanpa src = penampung.
const acak = (i: number, s: number): number => {
  const v = Math.sin(i * 12.9898 + s * 78.233) * 43758.5453;
  return v - Math.floor(v);
};

const poligonSobek = (seed: number): string => {
  const p: string[] = [];
  for (let x = 0; x <= 100; x += 5) p.push(`${x}% ${(acak(x, seed) * 1.8).toFixed(2)}%`);
  for (let y = 5; y <= 100; y += 5) p.push(`${(100 - acak(y, seed + 1) * 1.8).toFixed(2)}% ${y}%`);
  for (let x = 95; x >= 0; x -= 5) p.push(`${x}% ${(100 - acak(x, seed + 2) * 1.8).toFixed(2)}%`);
  for (let y = 95; y >= 5; y -= 5) p.push(`${(acak(y, seed + 3) * 1.8).toFixed(2)}% ${y}%`);
  return `polygon(${p.join(",")})`;
};

export const FotoSobek: React.FC<{
  x: number;
  y: number;
  w: number;
  h: number;
  rot?: number;
  src?: string;
  mulai?: number;
}> = ({x, y, w, h, rot = 0, src, mulai = 0}) => {
  const p = tampil(useMasuk(mulai));
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        width: w,
        height: h,
        opacity: p,
        transform: `rotate(${rot}deg) translateY(${(1 - p) * 50}px)`,
        filter: "drop-shadow(8px 10px 10px rgba(0,0,0,0.35))",
      }}
    >
      <div style={{width: "100%", height: "100%", clipPath: poligonSobek(Math.round(x + y)), background: "#f4efe2", padding: 12, boxSizing: "border-box"}}>
        {src ? (
          <Img
            src={staticFile(src)}
            style={{width: "100%", height: "100%", objectFit: "cover", filter: "grayscale(1) contrast(1.1) sepia(0.25)"}}
          />
        ) : (
          <div
            style={{
              width: "100%",
              height: "100%",
              background: "linear-gradient(160deg,#9a9a9a,#5d5d5d)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              textAlign: "center",
              color: "#f2f2f2",
              fontFamily: S.font,
              fontWeight: 700,
              fontSize: 30,
              padding: 20,
              boxSizing: "border-box",
            }}
          >
            FOTO ARSIP
            <br />
            (belum dipasang)
          </div>
        )}
      </div>
    </div>
  );
};

// Lingkaran merah gaya tangan yang tergambar sendiri
const bangunLingkaran = (cx: number, cy: number, rx: number, ry: number): string => {
  const n = 36;
  let d = "";
  for (let i = 0; i <= n + 3; i++) {
    const t = (i / n) * Math.PI * 2 - 0.4;
    const j = 1 + 0.035 * Math.sin(i * 2.3);
    const x = cx + rx * j * Math.cos(t) + i * 0.8;
    const y = cy + ry * j * Math.sin(t);
    d += `${i === 0 ? "M" : "L"} ${x.toFixed(1)} ${y.toFixed(1)} `;
  }
  return d;
};

export const LingkaranMerah: React.FC<{cx: number; cy: number; rx: number; ry: number; mulai: number}> = ({
  cx,
  cy,
  rx,
  ry,
  mulai,
}) => {
  const p = tampil(useMasuk(mulai, 24));
  return (
    <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: "absolute", left: 0, top: 0}}>
      <path
        d={bangunLingkaran(cx, cy, rx, ry)}
        pathLength={1}
        strokeDasharray={1}
        strokeDashoffset={1 - p}
        stroke={S.merah}
        strokeWidth={9}
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

export const Kredit: React.FC<{teks: string}> = ({teks}) => (
  <div
    style={{
      position: "absolute",
      left: 60,
      top: 1530,
      width: 960,
      fontFamily: S.font,
      fontSize: 22,
      lineHeight: 1.3,
      color: "rgba(32,36,64,0.7)",
    }}
  >
    {teks}
  </div>
);

type KartuTeksProps = {
  x: number;
  y: number;
  w: number;
  h: number;
  label?: Label;
  judul: string;
  sub?: string;
  mulai: number;
  ukuran?: number;
};

export const KartuTeks: React.FC<KartuTeksProps> = ({x, y, w, h, label, judul, sub, mulai, ukuran = 56}) => {
  const p = tampil(useMasuk(mulai));
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        width: w,
        height: h,
        opacity: p,
        transform: `translateY(${(1 - p) * 60}px) scale(${0.96 + 0.04 * p})`,
      }}
    >
      <Kartu style={{width: "100%", height: "100%"}}>
        {label ? <LabelPill label={label} /> : null}
        <div style={{fontFamily: S.font, fontWeight: 900, fontSize: ukuran, lineHeight: 1.15, color: S.navy, marginTop: label ? 18 : 0}}>
          {judul}
        </div>
        {sub ? (
          <div style={{fontFamily: S.font, fontWeight: 700, fontSize: 28, lineHeight: 1.3, color: "#5a5048", marginTop: 14}}>{sub}</div>
        ) : null}
      </Kartu>
    </div>
  );
};

export const KartuAngka: React.FC<{
  x: number;
  y: number;
  w: number;
  h: number;
  label: Label;
  besar: string;
  bulan: string;
  sub?: string;
  mulai: number;
}> = ({x, y, w, h, label, besar, bulan, sub, mulai}) => {
  const p = tampil(useMasuk(mulai));
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        width: w,
        height: h,
        opacity: p,
        transform: `translateY(${(1 - p) * 60}px) scale(${0.96 + 0.04 * p})`,
      }}
    >
      <Kartu style={{width: "100%", height: "100%"}}>
        <LabelPill label={label} />
        <div style={{fontFamily: S.font, fontWeight: 900, fontSize: besar.length > 3 ? 120 : 150, lineHeight: 1, color: S.navy, marginTop: 16}}>{besar}</div>
        <div style={{fontFamily: S.font, fontWeight: 900, fontSize: 52, color: S.navy}}>{bulan}</div>
        {sub ? <div style={{fontFamily: S.font, fontWeight: 700, fontSize: 26, color: "#5a5048", marginTop: 8}}>{sub}</div> : null}
      </Kartu>
    </div>
  );
};
