import React from "react";
import {Composition} from "remotion";
import {SandiPompeii} from "./sandi/SandiPompeii";
import {BeatData, totalDetik} from "./sandi/data";
import {FPS} from "./sandi/tema";
import dataPompeii from "../data/pompeii.json";

const LEBAR = 1080;
const TINGGI = 1920;

const DETIK_POMPEII = totalDetik(dataPompeii.beats as unknown as BeatData[]);
if (DETIK_POMPEII > 60) {
  console.warn(`Episode Pompeii ${DETIK_POMPEII} detik melebihi 60 detik.`);
}

export const RemotionRoot: React.FC = () => (
  <Composition
    id="SandiPompeii"
    component={SandiPompeii}
    durationInFrames={Math.round(DETIK_POMPEII * FPS)}
    fps={FPS}
    width={LEBAR}
    height={TINGGI}
  />
);
