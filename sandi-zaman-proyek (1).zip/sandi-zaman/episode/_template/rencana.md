# Rencana Episode — ISI NOMOR DAN JUDUL

Mode: RENCANA (teks saja). Tidak ada aset diunduh, tidak ada audio/video dibuat, tidak ada biaya.

## 1. Sudut misteri (satu kalimat)

## 2. Naskah narasi (target 50–60 detik; hitung kata dan estimasi durasi termasuk jeda)

## 3. Storyboard per beat
| Beat | Narasi | Pola komposisi | Foto/aset | Anotasi | Durasi |
|---|---|---|---|---|---|

## 4. Label klaim
| Klaim | Label (FAKTA / DUGAAN ILMIAH / BELUM TERJAWAB) | Sumber (URL + tanggal akses) | Kekuatan sumber |
|---|---|---|---|

## 5. Aset dan lisensi
| Beat | Aset | Pembuat | URL sumber | Lisensi | URL lisensi | Perubahan |
|---|---|---|---|---|---|---|
(hanya PD / CC0 / CC BY / CC BY-SA; tolak NC dan ND)

## 6. Tabel biaya
| Tahap | Alat | Status biaya |
|---|---|---|

## 7. Keputusan yang menunggu pengguna
