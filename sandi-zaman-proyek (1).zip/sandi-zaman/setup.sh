#!/usr/bin/env bash
# Menyiapkan alat Sandi Zaman di Codespaces (semua gratis): ffmpeg, Pillow, font DejaVu.
set -e
sudo apt-get update -y
sudo apt-get install -y ffmpeg fonts-dejavu-core python3-pip
python3 -m pip install --user pillow
echo "Selesai. Cek: ffmpeg -version && python3 -c 'import PIL; print(PIL.__version__)'"
