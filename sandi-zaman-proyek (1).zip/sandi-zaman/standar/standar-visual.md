# Standar Visual Sandi Zaman — v5

**Status: PERMANEN dan AKTIF untuk semua episode (rencana, produksi, revisi).**
v5 menggantikan v4. Sumber acuan: video referensi pengguna yang dilampirkan 3 November 2026
(20,3 dtk, 852×480) — **bukan** berkas pakai ulang, hanya acuan karakter visual dan teknik penyusunan.

> **Aturan konflik:** dokumen ini menang atas `panduan-gaya-visual.md`, `revisi-scrapbook.md`,
> `prosedur-lengkap.md`, dan `standar-visual-v4.md`. Bila sebuah dokumen lama masih menulis
> "tanpa lingkaran merah", "kartu lebih kecil dari kanvas", atau "latar diam total" — **dokumen itu
> sudah kedaluwarsa**; yang berlaku adalah v5 (§10 mendaftar aturan v4 yang dibatalkan).

---

## 0. Riwayat versi

| Versi | Status | Ciri |
|---|---|---|
| **v5** | **AKTIF — standar produksi semua episode** | kolase scrapbook penuh layar, foto arsip B/W tepi sobek, objek utama berwarna, anotasi tangan merah, gerak kamera halus |
| v4 | **DIGANTIKAN / arsip** (`standar-visual-v4.md`) | paper-cutout satu kartu 74%×56%, latar diam total, tanpa anotasi merah |
| v3 | warisan | kartu scrapbook bergantian + lingkaran spidol merah (`--style scrapbook`) |
| evidence | gaya khusus kasus kriminal | papan bukti `--style evidence` |

Video dan aset yang sudah jadi **tidak diubah/ditimpa**. v5 berlaku untuk produksi berikutnya.

---

## 1. Tujuh ciri wajib (diambil langsung dari video referensi)

Setiap beat/adegan harus memenuhi **minimal lima** dari tujuh ciri berikut; ciri 1, 2, 3, dan 7 wajib
di setiap episode.

1. **Kertas krem tua bertekstur** memenuhi seluruh layar (bukan bingkai, bukan latar putih).
2. **Foto arsip hitam-putih** dengan tepi sobek tidak beraturan dan rotasi kecil (±1–4°).
3. **Objek utama berwarna** yang menonjol di atas kolase (potongan bersih + outline stiker).
4. **Anotasi tangan merah**: lingkaran, garis penunjuk, angka tahun, catatan singkat.
5. **Foto bertumpuk** dengan variasi ukuran dan komposisi yang memenuhi layar.
6. **Gerak halus**: zoom, pan, dan perpindahan elemen (bukan potongan statis).
7. **Tata letak padat, jelas, mudah dibaca di layar HP** (bukan gambar kecil di tengah).

---

## 2. Anatomi lapisan (urutan dari bawah ke atas)

| # | Lapisan | Aturan |
|---|---|---|
| 1 | Kertas krem bertekstur | penuh 1080×1920; serat, lipatan, bercak samar; tidak ada bingkai/vignette berat |
| 2 | Foto arsip B/W | tepi sobek, bayangan lembut; 2–4 foto per beat; boleh terpotong tepi kanvas |
| 3 | Peta / dokumen / artefak | peta kuno, potongan koran, prasasti; B/W atau sepia |
| 4 | **Objek utama berwarna** | satu per beat; potongan latar bersih; outline putih + garis merah tipis; bayangan |
| 5 | Anotasi merah | 2–4 per beat; lihat §5 |
| 6 | Label & teks | label selotip kraft, catatan kaki, kredit satu baris, logo |

Lapisan 1–3 dan 5–6 dirender ke satu bingkai; lapisan 4 dirender terpisah agar bisa bergerak
sendiri (masuk → settle → drift) — lihat `build_collage_v5.py`.

---

## 3. Komposisi (WAJIB penuh layar)

- **Cakupan**: elemen kolase mengisi **80–95%** lebar dan tinggi frame. Tidak ada bidang kertas
  kosong besar di sekeliling komposisi.
- **Jumlah elemen**: minimal **2 foto + 1 elemen aksen** (peta/dokumen/objek); disarankan 3–4 foto.
- **Variasi ukuran**: satu foto dominan (28–45% lebar), satu sedang (18–25%), satu kecil
  (12–16%), boleh satu potongan yang keluar tepi kanvas.
- **Rotasi**: −4°…+4° per foto, tidak seragam.
- **Tumpang tindih**: foto saling menimpa 5–12% — bukan disusun rapi seperti grid.
- **Ruang aman**: 6% tepi kanvas bebas dari teks/kredit/logo (boleh ditembus foto, tidak boleh
  ditembus teks).
- **Pusat perhatian jelas**: objek berwarna atau anotasi merah terbesar, bukan di tengah mati —
  boleh 40/60 atau 55/45.
- **Template komposisi**: `panduan-komposisi-v5.md` (6 pola: L-overlap, pita vertikal, kluster
  kanan, pusat-pecah, peta+tumpuk, dua-kolom). Pilih pola berbeda untuk beat berurutan.

Dilarang: satu gambar kecil di tengah dengan kertas kosong luas, grid rapi, bingkai foto modern,
margin putih lebar, komposisi simetris membosankan.

---

## 4. Warna dan objek utama

- **Kertas**: `#E9E1CE` dasar, serat `#D8C9A8`, bayangan `#8A7552` (opasitas rendah).
- **Tinta teks**: `#2B2620`; teks sekunder `#5B4E3C`.
- **Merah anotasi**: `#B3202A` (goresan), varian gelap `#8F1620`.
- **Kraft/selotip**: `#C9B08A`, `#DCC79C`.
- **Foto arsip**: hitam-putih lembut; jangan colorize, jangan kontras ulang berlebihan.
- **Objek utama**: **warna asli dipertahankan** (ini pengecualian sadar terhadap aturan sepia v4).
  Warna objek harus berasal dari foto berlisensi atau aset pengguna — bukan hasil pewarnaan AI.
- Maksimal **satu** objek berwarna per beat agar tetap menonjol. Bila asetnya B/W semua, objek
  utama boleh tetap B/W dan penekanan dilakukan lewat anotasi merah.

---

## 5. Anotasi merah (aturan ketat)

Alat: goresan tangan (bukan bentuk vektor rapi), 2–3 lintasan, ujung terbuka, sedikit gemetar.

| Jenis | Aturan |
|---|---|
| Lingkaran | maksimal **1** per beat; mengelilingi detail nyata yang dibahas; jangan menutupi wajah/korban |
| Garis penunjuk / panah | maksimal **2** per beat; ujung panah menyentuh detail, bukan ruang kosong |
| Angka tahun | maksimal **1** per beat; font serif tebal; hanya tahun yang benar-benar ada di sumber |
| Catatan singkat | maksimal **1** per beat; ≤5 kata, huruf kapital, tinta gelap atau merah |
| Coretan/garis bawah | boleh, ≤2, untuk menandai kata kunci di dokumen |

Larangan anotasi:
- angka/tanggal yang tidak ada di sumber (mengarang tahun = pelanggaran fakta);
- anotasi pada foto korban jenazah/tragedi (mode tenang, §8);
- anotasi yang menutupi teks dokumen asli;
- lebih dari 4 anotasi per beat (layar jadi kotor dan tidak terbaca di HP).

---

## 6. Gerak dan tempo

- **Kamera bergerak halus**: zoom 1,00 → 1,04–1,06 sepanjang beat, atau pan ≤4% lebar.
  Arah bergantian antar beat (masuk/keluar), tanpa hentakan.
- **Elemen bergerak**: objek utama masuk dengan geser 30–60 px lalu *settle* 0,4–0,8 dtk,
  lalu drift halus; foto arsip boleh bergeser 4–12 px.
- **Latar kertas ikut bergerak bersama kamera** — v4 mewajibkan latar diam total, **v5 tidak**.
- **Ganti beat tiap 3–5 dtk**; transisi potong cepat atau geser 0,2–0,3 dtk. Tidak ada
  transisi sinematik (whip pan, zoom blur, flare).
- Keluaran tetap **1080×1920, 30 fps**. Tidak ada gerak yang mengubah keterbacaan teks.

---

## 7. Tipografi, label, kredit

- **Label tahun/tempat**: pita kraft atau kertas sobek, teks mono kapital — `JAPAN, 1957`,
  `THAILAND, 1960`. Hanya memuat fakta yang ada di sumber.
- **Catatan kaki**: 1–2 baris kecil di bawah, mono/serif, kontras cukup di HP.
- **Kredit**: satu baris ringkas di area aman bawah, tidak tertabrak logo.
- **Logo resmi** `brand_logo_sandi_zaman.png`: utuh, tidak diubah, tidak tertutup kolase/anotasi.
- **Tanpa subtitle terbakar**; SRT terpisah.
- Dilarang membuat dokumen, koran, atau headline palsu; dilarang teks AI tak terbaca.

---

## 8. Variasi per jenis episode

| Jenis | Perlakuan |
|---|---|
| A. Misteri/kasus kriminal | v5 penuh + label `EXHIBIT`, stempel arsip, benang merah; anotasi merah maksimal 4 |
| B. Arkeologi/peradaban | v5 dengan kertas lebih lapang, peta & artefak, tanpa benang merah |
| C. Tragedi dengan korban | **mode tenang**: 1–2 foto, tanpa lingkaran merah, tanpa selotip/stempel, objek berwarna hanya bila tidak eksploitatif, teks hormat hanya di deskripsi |
| D. Teori/rekonstruksi | v5 + cap **ILUSTRASI** pada aset AI; rekonstruksi tidak boleh menyerupai dokumen otentik |

Mode tenang (C) tetap **penuh layar** dan bertekstur kertas — bukan kartu kecil di tengah.

---

## 9. Fakta, hak penggunaan, dan aset AI

- Pertahankan foto arsip, peta, artefak, dan aset berlisensi yang sudah ada. **Jangan** mengganti
  foto arsip asli dengan gambar AI tanpa persetujuan pengguna.
- Jangan mengarang fakta, sumber, tahun, atribusi, atau detail visual yang tidak ada di sumber.
- Rekonstruksi AI wajib berlabel **ILUSTRASI** (di layar atau di deskripsi) dan tidak boleh
  menyerupai dokumen/artefak otentik.
- **Pemotongan objek** (cutout) dari foto berlisensi dicatat di kredit sebagai
  "perubahan: pemotongan latar". Tanpa URL halaman sumber → objek tidak ditayangkan.
- Lisensi: PD / CC0 / CC BY / CC BY-SA (tolak NC & ND).
- AI **hanya penambal** adegan yang belum punya visual memadai, dan hanya bila gratis (§11).

---

## 10. Aturan v4 yang DIBATALKAN (jangan diikuti lagi)

| Aturan v4 | Status di v5 |
|---|---|
| "Tanpa coretan/lingkaran spidol merah" | **dibatalkan** — anotasi merah kini wajib (§5) |
| Kartu 74%×56% dengan margin kertas | **dibatalkan** — komposisi penuh layar (§3) |
| "Latar belakang diam total" | **dibatalkan** — kamera bergerak halus (§6) |
| "Gambar penuh kanvas dilarang" | **dibatalkan** — penuh kanvas adalah standar |
| Semua foto berwarna dikonversi sepia | **dibatalkan untuk objek utama**; foto pendukung tetap B/W/sepia (§4) |
| Elemen stop-motion 8–12 fps + jitter | tidak wajib; gerak halus 30 fps boleh, jitter hanya hiasan kecil |
| Satu foto per adegan | **dibatalkan** — 2–4 foto bertumpuk per beat (§3) |

`standar-visual-v4.md` disimpan **hanya sebagai arsip**; jangan dipakai sebagai acuan produksi.

---

## 11. Biaya (Rp0)

1. Prioritas: aset lama/pengguna > foto arsip berlisensi > ilustrasi statis lokal > AI bila gratis.
2. Tanpa persetujuan eksplisit: **jangan** memakai kredit, membeli paket, atau mengaktifkan fitur berbayar.
3. Biaya/kuota tidak jelas → **berhenti dan laporkan**; tawarkan alternatif gratis.
4. Uji gratis ≠ gratis permanen. Render lokal ffmpeg/PIL selalu Rp0.

---

## 12. Implementasi teknis

### 12A. Renderer `build_collage_v5.py`

Menyusun frame kolase v5 dari **scene plan JSON**, lalu menambahkan gerak dan audio lewat ffmpeg.

```
python3 <path build_collage_v5.py> --plan /tmp/sz_ep/plan.json --audio /tmp/sz_ep/narasi.mp3 \
  --out /tmp/sz_ep/ep<NN>.mp4 --logo <path brand_logo_sandi_zaman.png> \
  --credit-line "Foto: … (CC BY-SA 4.0)" [--loudnorm] [--frames-only]
```

| Flag | Fungsi |
|---|---|
| `--plan` | scene plan JSON (skema di `panduan-komposisi-v5.md` §4) |
| `--audio` | narasi Charon; total durasi beat diskalakan ke durasi audio |
| `--logo` | overlay logo resmi, area aman kanan atas |
| `--credit-line` | satu baris kredit, dicetak di area aman bawah |
| `--loudnorm` | normalisasi akhir ke −16 LUFS / TP −1,5 dB (opsional, dilaporkan) |
| `--frames-only` | hanya menulis PNG tiap beat untuk pratinjau (tanpa video, Rp0) |
| `--paper` | tekstur kertas pengganti (default prosedural) |

Skema scene plan: `beats[]` berisi `dur`, `headline`, `caption`, `photos[]`, `cutout`, `annotations[]`,
`tape[]`. Koordinat memakai fraksi 0–1 dari frame. Renderer menolak plan yang melanggar v5
(kurang dari 2 foto, tidak ada kertas, teks di luar area aman, anotasi >4).

### 12B. QC wajib

```
python3 <path verify_short.py> hasil.mp4 --min 40 --max 300 --expect-no-subs \
  --expect-fullbleed --expect-camera-motion
python3 <path visual_coverage.py> --plan coverage.json --assets-dir <dir> --out laporan.md
```

Baca **4 frame** (awal, tengah beat pertama, tengah video, akhir) dan periksa manual: komposisi
padat, anotasi menunjuk detail nyata, kredit & logo terbaca, tidak ada teks AI rusak, tidak ada
subtitle terbakar.

---

## 13. Checklist sebelum ekspor

1. Tiap bagian narasi punya beat dengan **≥2 foto** + objek/aksen; tidak ada beat kosong.
2. Frame terisi 80–95%; tidak ada gambar kecil di tengah dengan kertas kosong luas.
3. Objek utama berwarna ada (atau alasan tertulis bila tidak ada) dan berlisensi.
4. Anotasi merah ≤4 per beat; tahun/angka ada di sumber; tidak menutupi wajah/korban.
5. Gerak halus ada (zoom/pan), bukan statis; teks tetap terbaca.
6. Label/tahun benar ejaannya; kredit terbaca; logo utuh; tanpa subtitle terbakar.
7. Cap ILUSTRASI hanya pada aset AI.
8. Simpan **berkas baru**; jangan menimpa sumber; jangan unggah otomatis.
