# Panduan Gaya Visual — Channel Sandi Zaman (selaras Standar Visual v5)

> **Precedence:** `standar-visual.md` **v5** menang atas dokumen ini. Bila berbeda, v5 yang berlaku.
> Dokumen ini mengatur **gaya, variasi per jenis, etika, dan teks** — bukan angka teknis.

---

## 1. Gaya inti (v5)

**Scrapbook arsip beranotasi merah**: meja kerja sejarawan. Kertas krem tua penuh layar, foto
arsip hitam-putih bertepi sobek bertumpuk, satu objek utama berwarna menonjol, dan tangan editor
yang menandai temuan dengan spidol merah — lingkaran, panah, tahun, catatan.

Kesan yang harus muncul di 1 detik pertama: **padat, bertekstur, dan “ini arsip sungguhan”**.
Bukan presentasi slide, bukan galeri foto, bukan kartu kecil di tengah layar.

## 2. Konsisten di semua episode

- **Palet:** kertas `#E9E1CE`, tinta `#2B2620`, merah anotasi `#B3202A`, kraft `#C9B08A`.
- **Satu objek berwarna** per beat — warna asli, bukan colorize AI.
- **Foto arsip** tetap hitam-putih; jangan diwarnai.
- **Font:** DejaVu Sans Mono (label/catatan/kredit), DejaVu Serif Bold (angka tahun).
- **Rasio:** 1080×1920, 30 fps, penuh layar.
- **Gerak:** kamera zoom/pan halus; elemen masuk lalu settle; tanpa hentakan sinematik.

## 3. Variasi per jenis episode

| Jenis | Perlakuan v5 | Parameter |
|---|---|---|
| **A. Misteri/kasus kriminal** | penuh: label `EXHIBIT`, stempel arsip, benang merah, anotasi maksimal 4 | `build_collage_v5.py` + `headline` “EXHIBIT A”, `annotations` 3–4 |
| **B. Arkeologi/peradaban** | kertas lebih lapang, peta & artefak dominan, tanpa benang merah, anotasi 1–2 | plan tanpa `tape` berlebih, `map` besar |
| **C. Tragedi dengan korban nyata** | **mode tenang**: 1–2 foto, tanpa lingkaran merah/stempel/selotip, objek berwarna hanya bila tidak eksploitatif; tetap penuh layar | `annotations: []`, `cutout` opsional |
| **D. Teori/rekonstruksi** | v5 + cap **ILUSTRASI** pada aset AI; rekonstruksi tidak menyerupai dokumen otentik | `--ilustrasi` di `build_short.py` (legacy) atau cap di plan |

Gaya khusus lama `--style evidence` / `--style scrapbook` (v3) hanya dipakai bila pengguna meminta
secara eksplisit. Default semua episode baru: **v5**.

## 4. Aturan stempel ILUSTRASI

- Hanya pada aset `rekonstruksi_ai`. Jangan pada foto arsip, foto situs, peta, artefak.
- Bila tidak ada aset AI, laporkan: **“stempel tidak dipakai”**.

## 5. Etika

- Foto korban (jenazah, cetakan tubuh): mode tenang, tanpa anotasi merah, tanpa dekorasi ramai.
- Stempel “barang bukti” (CONFIDENTIAL/EXHIBIT/RECEIVED) hanya untuk kasus kriminal, bukan situs
  sejarah atau bencana.
- Jangan memakai warna cerah yang mengalihkan perhatian dari korban.
- Sumber/lisensi setiap aset wajib ada di laporan QC dan kredit di layar.

## 6. Aturan teks

- Headline pita: kapital, ≤22 karakter, hanya fakta dari sumber (tempat/tahun).
- Catatan merah: ≤5 kata, kapital.
- Caption: 1–2 baris, ≤90 karakter, huruf kecil normal.
- Jangan menaruh subtitle narasi di layar. SRT terpisah.
- Teks yang dihasilkan AI dan rusak ejaannya: buang, tulis manual di plan.

## 7. Alur kerja per episode

1. Susun **scene plan** per beat (2–4 foto + objek/aksen, anotasi ≤4).
2. Pratinjau `--frames-only` → periksa PNG (padat? terbaca? anotasi menunjuk detail nyata?).
3. `visual_coverage.py` untuk cek aset/jenis/label.
4. Laporkan daftar beat, aset, sumber/lisensi, dan perkiraan biaya (default Rp0).
5. Render produksi setelah biaya jelas; QC `verify_short.py` v5.

## 8. Hindari

Gambar kecil di tengah dengan kertas kosong luas; bingkai foto modern; bayangan kartu 3D;
gradien glossy; neon; kartun/anime; komposisi grid rapi; teks AI tak terbaca; transisi sinematik
(whip pan, flare, zoom blur); latar putih bersih; letterbox 16:9.

## 9. Peta implementasi (jujur)

| Kebutuhan | Status |
|---|---|
| Kertas krem bertekstur penuh layar | `build_collage_v5.py` (prosedural, deterministik) |
| Foto B/W tepi sobek bertumpuk | `photos[]` + `torn: true` |
| Objek berwarna + outline stiker | `cutout` PNG (wajib aset berlisensi/pengguna) |
| Anotasi merah (lingkaran/panah/tahun/catatan) | `annotations[]`, maks 4 |
| Gerak zoom/pan + objek settle | ffmpeg di `build_collage_v5.py` |
| Label kraft + caption + kredit + logo | otomatis di renderer |
| QC penuh layar & gerak kamera | `verify_short.py --expect-fullbleed --expect-camera-motion` |
| Renderer v5 diuji render | **BELUM** — menunggu persetujuan pengguna |
| Pembuatan cutout otomatis (hapus latar) | belum ada; siapkan manual dari foto berlisensi |
