# Panduan Komposisi v5 — pola tata letak & skema scene plan

Pelengkap `standar-visual.md` v5. Isinya cara **mengisi layar** dan format data yang dibaca
`build_collage_v5.py`. Semua koordinat adalah **fraksi 0–1** dari frame 1080×1920:
`x` = pusat horizontal, `y` = pusat vertikal, `w`/`h` = lebar/tinggi elemen.

---

## 1. Prinsip pengisian layar

1. Satu beat = satu gagasan narasi. Isi dengan **2–4 foto + 1 aksen** (peta, dokumen, atau objek).
2. Satu foto **dominan**: lebar 0,28–0,45 dan tinggi 0,30–0,50. Sisanya lebih kecil.
3. Boleh **satu** elemen keluar tepi kanvas (x ± 0,05 atau w sampai 0,55) — justru membuat terasa
   seperti meja kerja yang penuh.
4. Jangan letakkan semua foto di satu garis. Variasikan y dengan selisih ≥ 0,10.
5. Rotasi −4°…+4°, tanda berlawanan antar foto yang bertumpuk.
6. Area kosong yang boleh: maksimal 15% frame, dan hanya di satu sisi.
7. Teks (headline, caption, kredit) selalu di area aman 6% tepi; foto boleh menembus tepi.

---

## 2. Enam pola komposisi

### Pola 1 — L-overlap (paling aman untuk pembuka)
```
foto besar kiri-atas      x .30 y .34 w .42 h .40
foto sedang kanan-atas    x .74 y .24 w .26 h .28
peta kecil kiri-bawah     x .22 y .74 w .30 h .24
objek utama kanan-bawah   x .62 y .64 w .46 h .40
tahun merah               x .86 y .08 size .085
```
Kesan: meja arsip penuh, mata bergerak dari tahun → objek → peta.

### Pola 2 — Pita vertikal
Tiga foto bertumpuk membentuk pita dari atas ke bawah di satu sisi (x ≈ 0,24; y 0,22 / 0,50 / 0,78),
objek berwarna besar di sisi lain (x 0,68; w 0,50) + satu anotasi lingkaran pada foto tengah.

### Pola 3 — Kluster kanan
Dua foto kecil bertumpuk di kanan (x 0,80; y 0,28 dan 0,62), satu foto besar kiri (x 0,32; w 0,46),
peta memanjang di dasar (x 0,35; y 0,86; w 0,60; h 0,18), catatan merah di ruang antar-foto.

### Pola 4 — Pusat-pecah (untuk pengungkapan / reveal)
Objek utama di tengah (x 0,50; w 0,56) dengan bagian terpisah (mis. atap terangkat) — dua foto
arsip kecil di sudut kiri-atas & kanan-bawah, satu foto lebar di belakang objek.
Gunakan hanya sekali per episode, pada momen pengungkapan.

### Pola 5 — Peta + tumpuk (untuk asal-usul/geografi)
Peta besar menempati 45% kiri (x 0,22; y 0,46; w 0,40; h 0,62), tiga foto arsip bertumpuk di kanan
(x 0,74; y 0,26 / 0,52 / 0,78; w 0,24), tahun merah besar di kanan-atas, lingkaran merah pada
satu lokasi peta. Garis penunjuk dari peta ke foto.

### Pola 6 — Dua kolom
Dua kolom foto (x 0,26 dan x 0,74) masing-masing 2 foto, objek berwarna menimpa kedua kolom di
tengah-bawah (x 0,50; y 0,68; w 0,48), headline pita di atas, caption di bawah.

---

## 3. Urutan pemakaian pola

| Beat | Pola |
|---|---|
| 1 (hook) | 1 atau 5 — langsung penuh, objek berwarna besar |
| 2 | 2 atau 6 |
| 3 | 3 |
| 4 (reveal) | 4 |
| 5+ | ulangi 1–3 dengan cermin (kiri↔kanan) |

Jangan memakai pola sama dua beat berurutan; jangan memakai pola 4 lebih dari sekali.

---

## 4. Skema scene plan JSON

```json
{
  "episode": 11,
  "credit": "Foto: Tropenmuseum (CC BY-SA 4.0) · Peta: BnF Gallica (PD)",
  "beats": [
    {
      "dur": 4.2,
      "headline": "JAPAN, 1957",
      "caption": "The tuk-tuk began in 1957 as a tiny Japanese delivery truck.",
      "photos": [
        {"src": "01_toko.jpg", "kind": "foto", "x": 0.30, "y": 0.34, "w": 0.42, "h": 0.40,
         "rot": -2.5, "sepia": true, "torn": true},
        {"src": "02_pabrik.jpg", "kind": "foto", "x": 0.74, "y": 0.24, "w": 0.26, "h": 0.28,
         "rot": 2.0, "z": 2}
      ],
      "map": {"src": "peta_1957.jpg", "x": 0.22, "y": 0.74, "w": 0.30, "h": 0.24, "rot": 1.5},
      "cutout": {"src": "tuktuk.png", "x": 0.62, "y": 0.64, "w": 0.46, "rot": -3.0,
                 "outline": true},
      "annotations": [
        {"type": "circle", "x": 0.22, "y": 0.70, "rx": 0.11, "ry": 0.09, "rot": -8},
        {"type": "arrow", "x1": 0.60, "y1": 0.40, "x2": 0.47, "y2": 0.52},
        {"type": "year", "text": "1957", "x": 0.84, "y": 0.09, "size": 0.085, "rot": -2},
        {"type": "note", "text": "A ROOF. A BENCH.", "x": 0.78, "y": 0.52, "size": 0.020}
      ],
      "tape": [{"x": 0.28, "y": 0.035, "rot": -7, "w": 0.20}]
    }
  ]
}
```

### Field

| Field | Wajib | Keterangan |
|---|---|---|
| `dur` | ya | durasi beat (dtk); total diskalakan ke durasi audio |
| `headline` | tidak | teks pita kraft, kapital, maks 22 karakter |
| `caption` | tidak | 1–2 baris catatan kaki, maks 90 karakter |
| `photos[]` | ya (≥2) | `src`, `x`, `y`, `w`, `h`, `rot`; opsional `kind` (`foto`/`peta`/`dokumen`), `sepia`, `torn`, `z` |
| `map` | tidak | satu peta/dokumen besar (setara foto, `sepia` default true) |
| `cutout` | tidak | objek utama berwarna: PNG latar transparan, `outline: true` menambah outline putih + garis merah |
| `annotations[]` | tidak | maks 4; tipe `circle`, `arrow`, `year`, `note`, `underline` |
| `tape[]` | tidak | selotip kertas: `x`, `y`, `rot`, `w` |

### Aturan validasi (renderer menolak plan yang melanggar)
- `photos` < 2 → tolak (`KOMPOSISI_TERLALU_KOSONG`).
- `annotations` > 4 → tolak (`ANOTASI_BERLEBIHAN`).
- `headline`/`caption`/`credit` keluar area aman 6% → tolak (`TEKS_DI_LUAR_AREA_AMAN`).
- `cutout` lebih dari satu per beat → tolak (`OBJEK_BERWARNA_GANDA`).
- foto tidak ditemukan → berhenti, jangan render.

---

## 5. Aturan cutout (objek berwarna)

1. Sumber: foto berlisensi atau aset pengguna; **bukan** hasil generate AI untuk menggantikan foto arsip.
2. Latar dihapus bersih (PNG transparan). Tepi tidak perlu sempurna — outline menutupinya.
3. Outline: putih 10–18 px + garis merah 2–3 px di luar putih.
4. Bayangan lembut ke kanan-bawah, bukan hitam pekat.
5. Ukuran objek 0,35–0,56 lebar frame; jangan lebih besar dari itu agar tidak jadi poster.
6. Catat di kredit: "perubahan: pemotongan latar".

## 6. Aturan teks di layar

- `headline`: kapital, mono, ≤22 karakter, satu baris.
- `caption`: 1–2 baris, 90 karakter maks, ukuran 26–34 px, kontras cukup.
- Kredit: satu baris, ≤110 karakter, di area aman bawah (di atas 4% tepi).
- Jangan pernah membakar subtitle narasi. SRT terpisah.
