# Standar Narasi — Sandi Zaman

Berlaku untuk semua episode (`rencana`, `produksi`, `revisi`). Acuan pembawaan:
**`narasi_referensi_utama_v2.mp3`** (Standar Suara v1.0 — lihat `standar-suara-v1.md`).
`narasi_referensi_utama_v1.mp3` dan `narasi_referensi.mp3` tetap disimpan sebagai pembanding; jangan diubah atau dihapus.

> **Kejujuran teknologi.** Acuan audio dipakai untuk **gaya pembawaan** (tempo, jeda,
> penekanan, karakter). Kita **tidak** mengklaim meniru identik suara pada referensi dan
> tidak melakukan kloning suara. Yang dipakai tetap voice **Charon** yang sudah disepakati.

---

## 1. Voice dan alat

- Voice: **Charon** standar. Jangan mengganti voice, menambah efek "suara berbeda", atau
  mengklaim hasilnya identik dengan referensi.
- Bahasa Indonesia natural, baku namun tidak kaku; artikulasi jelas, tidak terburu-buru.
- Nada: dokumenter sejarah — serius, hangat, penasaran, misterius secara wajar (bukan horor).
- Bila TTS Charon ternyata memerlukan kredit/biaya: **berhenti dan laporkan** sesuai
  `kebijakan-biaya.md`. Tidak ada alternatif berbayar diam-diam.

## 2. Karakter pembawaan (acuan: narasi_referensi_utama_v2.mp3)

- Penekanan pada fakta penting, penemuan, pertentangan bukti, dan pertanyaan yang belum terjawab.
- **Jeda alami** sebelum pengungkapan penting dan sesudah kalimat mengejutkan (tulis `[jeda]` di naskah), mengikuti ambang terukur di `standar-suara-v1.md` §3.
- Intonasi dan tempo bervariasi mengikuti isi cerita; hindari monoton dan "membaca daftar fakta".
- Utamakan kejelasan; jangan mempercepat audio hanya untuk mengejar durasi.
- Kalimat pendek untuk ketegangan, kalimat mengalir untuk penjelasan.

## 3. Hook dan retensi

1. Buka dengan kalimat yang langsung menimbulkan pertanyaan atau kejutan **berbasis fakta**.
2. Dalam beberapa detik pertama berikan alasan kuat untuk terus menyimak (taruhan, bukti, konflik).
3. Susun bertahap: petunjuk → bukti → konflik/tafsir bersaing → pengungkapan.
4. Jangan membocorkan seluruh jawaban di awal.
5. Tutup dengan kesimpulan memuaskan + satu pertanyaan lanjutan yang relevan (open loop),
   hanya jika episode berikutnya memang direncanakan.
6. Dilarang clickbait palsu, misteri karangan, atau melebih-lebihkan bukti.

## 4. Durasi

- **Tidak ada batas kaku 60 detik.** Pilih durasi dari kebutuhan cerita.
- Panduan praktis: 45–90 detik untuk satu misteri; boleh lebih panjang bila fakta dan jeda
  dramatis menuntutnya.
- Jangan mempercepat narasi (atau memotong fakta) hanya agar pas durasi tertentu.
- Sinkronkan durasi adegan visual dengan narasi — **jangan** memotong narasi demi visual.
- Naskah ±135 kata/menit dipakai sebagai perkiraan awal, bukan target wajib.

## 5. Penutup dan kesinambungan

- Akhiri dengan satu pertanyaan lanjutan yang benar-benar bersumber dari fakta/tafsir yang dibahas.
- Jangan menjanjikan episode yang tidak ada.
- Naskah yang sudah disetujui pengguna tidak diubah tanpa izin.

## 6. QC narasi (sebelum menyerahkan)

1. Dengarkan penuh: kejelasan, jeda, penekanan, tidak monoton, tidak terburu-buru.
2. Pastikan tidak ada salah ucap nama tempat/tokoh/tahun; cek ulang ke sumber.
3. Durasi audio = durasi video (±0,3 s); tidak ada narasi terpotong.
4. Tidak ada klaim berlebihan atau clickbait palsu di naskah.
5. Catat di ringkasan: "narasi Charon, acuan pembawaan `narasi_referensi_utama_v2.mp3` (Standar Suara v1.0); bukan kloning suara".
6. Ukur ulang jeda/porsi diam/F0 dari WAV dan bandingkan dengan `standar-suara-v1.md` §3; laporkan penyimpangan, jangan diam-diam menerima.
