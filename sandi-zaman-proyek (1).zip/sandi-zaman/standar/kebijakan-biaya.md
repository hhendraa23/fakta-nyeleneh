# Kebijakan Biaya Permanen — Sandi Zaman

Wajib untuk **seluruh episode, semua tugas, dan semua tahap** (riset, naskah, aset, narasi,
storyboard, produksi, render, QC). Tidak perlu diulang oleh pengguna di setiap episode.

---

## 1. Prioritas anggaran

1. **Pilihan pertama selalu Rp0**: alat gratis, pemrosesan lokal (ffmpeg + PIL), aset lokal
   yang sudah tersedia, dan sumber visual dengan lisensi jelas.
2. Bila suatu proses tidak bisa Rp0 → **cari alternatif gratis** lebih dulu.
3. Bila alternatif gratis benar-benar tidak ada → laporkan opsi berbiaya **paling rendah**
   beserta harga dan kebutuhan kredit yang terverifikasi. **Jangan jalankan** sebelum pengguna
   memberi persetujuan eksplisit.
4. Uji coba gratis, kuota terbatas, dan kredit awal **bukan** "gratis permanen". Periksa batas
   penggunaan dan biaya berikutnya.

## 2. Larangan tanpa persetujuan eksplisit

- Memakai kredit Creao atau kredit generasi AI (gambar/video/audio).
- Membeli paket, berlangganan, upgrade, memasukkan kartu pembayaran, mengaktifkan fitur berbayar.
- Menjalankan proses yang biaya atau penggunaan kreditnya **tidak jelas**.
- Mengganti alat dengan layanan berbayar secara diam-diam.
- Mengunggah atau menjadwalkan video ke YouTube/platform lain secara otomatis.

## 3. Penghematan produksi

- Gunakan ulang video, audio, logo, gambar, dan aset proyek lama yang masih layak.
- Gerakan visual memakai **FFmpeg** lokal (animasi masuk, zoom lambat) — bukan video generatif.
- Ilustrasi AI hanya bila alat, kuota, dan prosesnya **dipastikan gratis**.
- Voice Charon hanya bila akses TTS-nya **tanpa biaya tambahan**; bila butuh kredit → berhenti.
- Musik hanya bila benar-benar gratis dan lisensinya sesuai; musik tidak wajib.
- Hindari render ulang yang tidak perlu: periksa aset, naskah, dan parameter lebih dulu.

## 4. Gerbang persetujuan

Sebelum setiap proses yang **dapat** memakai kredit atau biaya:

1. Sebutkan prosesnya, alatnya, dan perkiraan biaya/kuota.
2. Bila status Rp0 tidak dapat dipastikan → **hentikan** proses terkait, jangan lanjut, jangan cari
   jalan diam-diam; laporkan dan tunggu persetujuan.
3. Bila pengguna menolak biaya → tawarkan alternatif gratis atau hentikan produksi.

## 5. Pelaporan setelah produksi

Catat dan laporkan:

- alat yang benar-benar dipakai per tahap,
- status biaya tiap tahap (Rp0 / berpotensi kredit / berbayar),
- penggunaan kredit yang **terbukti** (bukan asumsi),
- berkas yang **benar-benar dihasilkan** (nama, durasi, ukuran).

Jangan mengklaim "biaya nol" atau "produksi berhasil" tanpa bukti yang memadai. Jika ada tahap
yang tidak dijalankan karena biaya, sebutkan secara eksplisit di ringkasan.

## 6. Pengecualian yang tidak pernah berlaku

Tidak ada pengecualian otomatis untuk "episode penting", "kualitas lebih baik", "sekali saja",
atau batas waktu. Persetujuan pengguna harus eksplisit dan spesifik untuk proses tersebut.
