# STANDAR SUARA SANDI ZAMAN — REFERENSI NARASI UTAMA v1.0

**Versi dokumen 1.1 — diperbarui dengan acuan narasi v2.**
**Status: PERMANEN — STANDAR BAWAAN.** Berlaku untuk **semua** episode berikutnya, semua revisi narasi, semua segmen audio, semua Shorts sejarah & misteri Sandi Zaman. Bukan catatan satu episode. Tidak boleh diabaikan tanpa persetujuan eksplisit pengguna.

## Acuan resmi

| Peran | Berkas | Catatan |
|---|---|---|
| **Acuan utama (aktif)** | `narasi_referensi_utama_v2.mp3` | 82,44 dtk — lampiran pengguna 31 Okt, ditetapkan sebagai referensi narasi utama |
| Acuan pendukung | `narasi_referensi_utama_v1.mp3` | 84,43 dtk — take sebelumnya, karakter sama; dipakai bila butuh pembanding |
| Acuan lama | `narasi_referensi.mp3`, `charon_reference.mp3` | arsip; **jangan diubah/dihapus** |

Path semua berkas diambil dari `cat /home/user/agent/app-files.json` (cocokkan `name`, pakai `path`).

**Berkas audio referensi HANYA acuan gaya pembawaan (listening reference).** Bukan bahan narasi, bukan voiceover, tidak pernah masuk timeline, tidak pernah diulang sebagai audio episode.

---

## 1. Fungsi audio referensi

Dipakai hanya untuk memahami: karakter & warna suara, nada bicara, intonasi per kalimat, kecepatan bicara, penekanan kata penting, jeda alami antarkalimat, cara membangun kesan misterius dan rasa penasaran, serta gaya penyampaian dokumenter sejarah.

**Dilarang keras:**
- Menempelkan audio referensi ke timeline, mengulangnya sebagai voiceover, atau memakainya sebagai narasi episode.
- Menggantikan narasi episode baru dengan rekaman referensi.
- Memakai berkas itu untuk apa pun selain pembacaan gaya.
- Mengubah, memotong, menormalkan, atau menghapus berkas audio referensi asli.

Setiap episode memakai **naskah baru** dan menghasilkan **narasi baru** yang karakternya mengikuti referensi.

---

## 2. Karakter suara yang ditetapkan

| Aspek | Standar |
|---|---|
| Bahasa | Indonesia natural, jelas, tidak kaku |
| Jenis suara | Pria dewasa |
| Nada | Tenang, berat, berwibawa |
| Nuansa | Misterius, dokumenter sejarah |
| Intonasi | Hidup, bervariasi, tidak monoton |
| Tempo | Sedang, tidak terburu-buru |
| Penekanan | Mengikuti makna kalimat, bukan pola seragam |
| Jeda | Alami, terutama sebelum ketegangan atau pengungkapan |
| Yang dilarang | Terdengar robotik; gaya trailer film horor; dramatisasi berlebihan |

Jangan mengarang karakter suara yang berbeda dari referensi.

---

## 3. Target terukur dari audio referensi

Metode: decode WAV 24 kHz mono, envelope RMS 20 ms/hop 10 ms, ambang adaptif, jeda dihitung ≥ 0,25 dtk, F0 via autokorelasi 40 ms. Diukur pada kedua referensi agar konsisten.

| Ukuran | v2 (acuan aktif) | v1 (pembanding) | Ambang produksi |
|---|---|---|---|
| Durasi berkas | 82,44 dtk | 84,43 dtk | — |
| Porsi bicara | 84,8% | 80,1% | 82–90% |
| Porsi diam | 10,6% (8,8 dtk) | 16,8% (14,2 dtk) | **9–15%** |
| Jumlah jeda | 23 | 30 | — |
| Jeda per menit bicara | 19,7 | 26,6 | **18–22** |
| Panjang jeda rata-rata | **0,38 dtk** | 0,47 dtk | **0,32–0,50 dtk** |
| Rentang jeda | 0,25–0,64 dtk | 0,25–0,96 dtk | tidak ada jeda > 0,75 dtk (kecuali jeda dramatis yang disengaja) |
| Rata-rata frasa antar-jeda | **3,04 dtk** | 2,25 dtk | 2,5–3,5 dtk |
| F0 median | **156,9 Hz** | 154,8 Hz | 145–170 Hz |
| Rentang F0 (P10–P90) | 116,5–224,3 Hz (11,3 semiton) | 113,7–216,2 Hz | ≥ 8 semiton — wajib bervariasi, bukan datar |
| Centroid spektral (median) | 1.611 Hz | 1.590 Hz | 1.400–1.800 Hz (timbre berat, bukan tipis) |
| Loudness referensi | −19,0 LUFS / TP −2,8 dBFS / LRA 2,8 LU | −19,8 LUFS / TP −2,8 dBFS | acuan rasa, **bukan** target akhir |
| Target akhir video | — | — | **−16 LUFS, true peak ≤ −1 dBFS** (loudnorm dua lintasan) |

Catatan: loudness referensi lebih pelan daripada target akhir. Itu wajar — referensi adalah rekaman mentah, sedangkan video perlu level siar. Jangan menyamakan keduanya.

Temuan penting dari v2: take ini **lebih rapat** daripada v1 — jeda rata-rata lebih pendek (0,38 vs 0,47 dtk), frasa lebih panjang (3,04 vs 2,25 dtk), porsi diam lebih kecil. Karakter suara tetap sama (F0 & centroid hampir identik), jadi yang berubah adalah **kepadatan penyampaian**, bukan warna suara. Acuan produksi mengikuti v2.

---

## 4. Batas teknologi — WAJIB dilaporkan jujur

Mesin suara yang tersedia adalah **TTS Gemini (Google)** dengan pilihan voice tetap: `Charon`, `Rasalgethi`, `Iapetus`, `Orus`, `Gacrux`, `Alnilam`, `Schedar`, `Enceladus`, `Umbriel`, dan sejumlah voice wanita.

Konsekuensi yang harus disampaikan ke pengguna setiap kali relevan:

1. **Timbre tidak bisa dikloning.** Tidak ada fitur voice cloning. Yang bisa didekati hanya **gaya**: tempo, jeda, penekanan, tinggi-rendah intonasi, dan nuansa — lewat arahan `style` + tag audio (`[curiosity]`, `[short pause]`, `[determination]`, `[awe]`, `[sadness]`, `[nervousness]`).
2. **Voice tetap `Charon`.** Jangan mengganti voice tanpa persetujuan eksplisit.
3. **Tempo tidak bisa dikunci persis.** Pengukuran menunjukkan variasi antar-generasi ±3–5% bahkan dengan arahan yang sama (Charon pernah menghasilkan 1,73–1,98 kata/detik pada arahan setara). Karena itu durasi selalu **diukur ulang**, tidak pernah diprediksi.
4. Kalimat yang menyatakan "meniru suara referensi secara identik" **dilarang** di laporan mana pun. Rumusan yang benar: "mengikuti gaya pembawaan referensi; bukan kloning suara".

---

## 5. Resep pembawaan (dipakai di setiap pemanggilan TTS)

Voice: `Charon`.

`style` baku (boleh disesuaikan tema, tidak boleh mengubah karakternya):

> Adult male documentary narrator. Calm, low, heavy and mysterious, in natural Indonesian. Moderate tempo, never rushed. Clear articulation with confident authority. Natural, fairly tight pauses between sentences — around 0.3 to 0.5 seconds — with slightly longer phrasing of about 3 seconds per phrase. Expressive pitch movement, never flat. Never robotic, never shouting, never horror-trailer delivery.

Tag dipakai hemat, **maksimal 1 tag per kalimat**:
- `[curiosity]` — pembuka, pertanyaan, rasa penasaran
- `[awe]` — penemuan, keajaiban arkeologi
- `[sadness]` — korban, kehilangan
- `[determination]` — fakta, bukti, kesimpulan
- `[nervousness]` — ketegangan menjelang bencana
- `[short pause]` — jeda 0,3–0,5 dtk; jangan pakai `[long pause]` kecuali diminta

Aturan penempatan jeda mengikuti referensi:
- Satu jeda pendek setelah frasa pembuka yang menggantung ("Bayangkan…", "Pada tahun 79 Masehi,").
- Satu jeda sebelum pengungkapan atau angka penting.
- Tidak ada dua tag berdampingan.
- Jangan menaruh tanda baca dramatis berlebihan (titik-titik panjang, huruf kapital penuh) untuk mengejar efek — hasilnya justru keluar dari ambang jeda.

---

## 6. Verifikasi wajib setelah narasi dibuat

1. Decode WAV (`ffmpeg -i narasi.mp3 -ar 24000 -ac 1 out.wav`) — **jangan** percaya durasi mp3 mentah; berkas TTS kerap ber-header rusak dan selisihnya bisa mencapai ±0,9 dtk per segmen.
2. Ukur per segmen: durasi, laju kata/detik, porsi diam, jumlah & rata-rata jeda, F0 median & rentang.
3. Bandingkan dengan tabel §3. Bila jeda rata-rata < 0,30 dtk atau > 0,60 dtk, porsi diam di luar 9–15%, atau rentang F0 < 8 semiton (terdengar datar), **laporkan** — jangan diam-diam menerima.
4. Narasi yang sudah disetujui tidak boleh diubah tanpa izin. Mempercepat/memperlambat audio dengan `atempo` hanya boleh bila pengguna memintanya, dan hasilnya harus dilaporkan (tempo & pitch tidak berubah, tapi jeda ikut memendek).

---

## 7. Hubungan dengan dokumen lain

- `standar-narasi.md` mengatur **isi** naskah (hook, struktur, durasi).
- Dokumen ini mengatur **pembawaan suara**. Bila keduanya bersinggungan pada tempo/jeda, dokumen ini yang menang.
- `kebijakan-biaya.md` tetap berlaku: tidak ada TTS berbayar tanpa persetujuan eksplisit.
- `prosedur-lengkap.md` langkah 4 (Narasi Charon) wajib merujuk dokumen ini.
