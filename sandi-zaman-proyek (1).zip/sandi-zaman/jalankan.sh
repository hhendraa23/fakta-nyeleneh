#!/usr/bin/env bash
# Pemakaian:
#   bash jalankan.sh episode/12 pratinjau   -> PNG tiap beat (cepat, tanpa video)
#   bash jalankan.sh episode/12 render      -> video MP4 penuh + QC
# Folder episode berisi: plan.json, narasi.mp3, kredit.txt, dan folder aset/
set -e
EP="${1:?Sebutkan folder episode, mis. episode/12}"
MODE="${2:-pratinjau}"
cd "$(dirname "$0")"

[ -f "$EP/plan.json" ] || { echo "Tidak ada $EP/plan.json"; exit 1; }
KREDIT=""
[ -f "$EP/kredit.txt" ] && KREDIT="$(head -n 1 "$EP/kredit.txt")"

if [ "$MODE" = "pratinjau" ]; then
  mkdir -p "$EP/pratinjau"
  # audio tidak dipakai pada mode pratinjau, tetapi argumen wajib ada
  AUDIO="$EP/narasi.mp3"
  [ -f "$AUDIO" ] || { ffmpeg -v error -y -f lavfi -i "anullsrc=r=44100:cl=mono" -t 1 -c:a libmp3lame /tmp/kosong.mp3; AUDIO=/tmp/kosong.mp3; }
  python3 alat/build_collage_v5.py --plan "$EP/plan.json" --audio "$AUDIO" \
    --logo alat/brand_logo_sandi_zaman.png --credit-line "$KREDIT" \
    --frames-only --out "$EP/pratinjau"
  echo "Pratinjau ada di $EP/pratinjau (beatNN_base.png + beatNN_cut.png)"
elif [ "$MODE" = "render" ]; then
  [ -f "$EP/narasi.mp3" ] || { echo "Render butuh $EP/narasi.mp3 (narasi baru, bukan file acuan)"; exit 1; }
  mkdir -p "$EP/hasil"
  python3 alat/build_collage_v5.py --plan "$EP/plan.json" --audio "$EP/narasi.mp3" \
    --logo alat/brand_logo_sandi_zaman.png --credit-line "$KREDIT" --loudnorm \
    --out "$EP/hasil/short.mp4"
  python3 alat/verify_short.py "$EP/hasil/short.mp4" --min 50 --max 60 \
    --expect-no-subs --expect-fullbleed --expect-camera-motion
  echo "Selesai: $EP/hasil/short.mp4 (belum diunggah)"
else
  echo "Mode harus 'pratinjau' atau 'render'"; exit 1
fi
