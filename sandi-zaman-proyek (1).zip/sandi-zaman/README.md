# SANDI ZAMAN — proyek Shorts sejarah misteri (kolase scrapbook)

Berisi alat dari agen Sandi Zaman v1.13.0 yang bisa dijalankan sendiri di Codespaces, gratis:
- `alat/build_collage_v5.py` : renderer kolase scrapbook v5 (Pillow + FFmpeg, tanpa jaringan)
- `alat/commons_fetch.py`    : mengunduh aset Wikimedia beserta metadata lisensi (butuh internet)
- `alat/verify_short.py`     : QC video (durasi, resolusi, gerak kamera, tanpa subtitle terbakar)
- `alat/visual_coverage.py`  : QC cakupan narasi -> aset
- `standar/`                 : standar visual v5, komposisi v5, narasi, suara, kebijakan biaya

## Pemasangan (sekali)
    bash sandi-zaman/setup.sh

## Alur satu episode
1. Salin `episode/_template` menjadi `episode/12` (ganti angka sesuai episode).
2. Isi `rencana.md` (naskah, storyboard, label klaim, aset+lisensi, biaya). Tunggu persetujuan.
3. Unduh aset berlisensi ke `episode/12/aset/` dan tulis `episode/12/kredit.txt` (satu baris).
4. Tulis `episode/12/plan.json` mengikuti `standar/panduan-komposisi-v5.md`.
5. Pratinjau tata letak:  `bash sandi-zaman/jalankan.sh episode/12 pratinjau`
6. Taruh narasi BARU di `episode/12/narasi.mp3`.  File acuan narasi hanya acuan gaya, jangan dijadikan narasi.
7. Render + QC:  `bash sandi-zaman/jalankan.sh episode/12 render`

## Catatan penting
- Biaya harus Rp0. Jangan jalankan TTS atau layanan lain yang bisa memakai kredit tanpa memastikan gratisnya.
- Tahun 4 digit pada `size` 0.085 lebarnya sekitar 0,39 dari layar: letakkan `x` paling besar sekitar 0,78 agar tidak terpotong tepi.
- Video tidak pernah diunggah otomatis.
