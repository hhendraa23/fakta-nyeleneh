#!/usr/bin/env python3
"""QC cakupan visual: bagian narasi -> aset -> jenis -> status.

Menjawab satu pertanyaan: "apakah setiap bagian narasi punya visual?"
Skrip ini TIDAK bisa menilai relevansi semantik; kolom relevansi selalu
PERLU_REVIEW_MANUAL kecuali ditandai manual oleh editor.

Pemakaian:
  python3 visual_coverage.py --plan coverage.json --out laporan.md [--assets-dir DIR] [--json]

Format coverage.json:
{
  "episode": 11,
  "judul": "Pompeii",
  "sections": [
    {"id": "S1", "narration": "Jalan dan kota Pompeii",
     "asset": "04_Via_dell_Abbondanza.jpg", "type": "foto_arsip",
     "ai_generated": false, "label_ilustrasi": false,
     "relevance_checked": false, "note": ""}
  ]
}

Jenis aset yang sah: foto_arsip | foto_situs_modern | peta_dokumen | ilustrasi_statis |
rekonstruksi_ai | potongan_objek (cutout objek berwarna, wajib kredit "pemotongan latar")
Keluar kode 1 bila ada bagian BELUM_ADA atau label ILUSTRASI hilang.
"""
import argparse, json, os, sys

TYPES = {
    "foto_arsip": "Foto arsip asli (historis)",
    "foto_situs_modern": "Foto situs/artefak modern (bukan arsip sejarah)",
    "peta_dokumen": "Peta/dokumen/artefak",
    "ilustrasi_statis": "Ilustrasi statis (non-AI)",
    "rekonstruksi_ai": "Rekonstruksi AI (wajib label ILUSTRASI)",
    "potongan_objek": "Potongan objek berwarna/cutout (kredit: pemotongan latar)",
}

def evaluate(plan, assets_dir):
    rows, problems = [], []
    used = {}
    sections = plan.get("sections") or []
    for i, s in enumerate(sections, 1):
        sid = s.get("id") or f"S{i}"
        narr = (s.get("narration") or "").strip()
        asset = (s.get("asset") or "").strip()
        atype = (s.get("type") or "").strip()
        ai = bool(s.get("ai_generated"))
        label = bool(s.get("label_ilustrasi"))
        rel_checked = bool(s.get("relevance_checked"))

        status, detail = "OK", []
        if not narr:
            status = "PERLU_REVIEW_MANUAL"
            detail.append("teks narasi kosong")
        if not asset:
            status = "BELUM_ADA"
            detail.append("belum ada aset")
        else:
            path = asset if os.path.isabs(asset) else os.path.join(assets_dir, asset)
            if not os.path.exists(path):
                status = "BELUM_ADA"
                detail.append(f"berkas tidak ditemukan: {os.path.basename(asset)}")
            else:
                used.setdefault(asset, []).append(sid)
        if atype not in TYPES:
            if status == "OK":
                status = "PERLU_REVIEW_MANUAL"
            detail.append(f"jenis aset tidak dikenal: '{atype}'")
            problems.append(f"{sid}: JENIS_TIDAK_DIKENAL ('{atype}')")
        if ai and atype != "rekonstruksi_ai":
            if status == "OK":
                status = "PERLU_REVIEW_MANUAL"
            detail.append("ditandai ai_generated tetapi jenis bukan rekonstruksi_ai")
        if atype == "rekonstruksi_ai" and not label:
            status = "LABEL_HILANG"
            detail.append("rekonstruksi AI tanpa label ILUSTRASI")
        if status in ("BELUM_ADA", "LABEL_HILANG"):
            problems.append(f"{sid}: {status}")

        rows.append({
            "id": sid, "narration": narr, "asset": asset or "-",
            "type": TYPES.get(atype, atype or "-"), "status": status,
            "relevance": "OK (manual)" if rel_checked else "PERLU_REVIEW_MANUAL",
            "detail": "; ".join(detail),
        })

    for asset, ids in used.items():
        if len(ids) > 1:
            for r in rows:
                if r["asset"] == asset:
                    r["detail"] = (r["detail"] + "; " if r["detail"] else "") + \
                                  f"aset dipakai di {len(ids)} bagian ({', '.join(ids)})"
                    if r["status"] == "OK":
                        r["status"] = "PERLU_REVIEW_MANUAL"
    return rows, problems

def to_markdown(plan, rows, problems, assets_dir):
    n = len(rows)
    counts = {}
    for r in rows:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
    out = [f"# QC Cakupan Visual — {plan.get('judul','')} (Episode {plan.get('episode','?')})", "",
           f"Bagian narasi: **{n}** · aset dir: `{assets_dir}`", "",
           "| Bagian | Narasi (ringkas) | Aset | Jenis | Status cakupan | Relevansi | Catatan |",
           "|---|---|---|---|---|---|---|"]
    for r in rows:
        narr = r["narration"][:60].replace("|", "/") or "-"
        out.append(f"| {r['id']} | {narr} | `{os.path.basename(r['asset'])}` | {r['type']} | "
                   f"**{r['status']}** | {r['relevance']} | {r['detail'] or '-'} |")
    out += ["", "## Ringkasan", ""]
    for k in ("OK", "PERLU_REVIEW_MANUAL", "BELUM_ADA", "LABEL_HILANG"):
        if k in counts:
            out.append(f"- {k}: {counts[k]}")
    out += ["", "## Catatan kejujuran", "",
            "- Skrip ini **tidak** menilai relevansi isi gambar. Semua baris yang belum diperiksa editor",
            "  ditandai `PERLU_REVIEW_MANUAL` — bukan berarti visualnya sudah benar.",
            "- `OK` hanya berarti: aset ada, jenis dikenali, dan (bila AI) label ILUSTRASI ada.",
            "- Keberadaan nama berkas **tidak** membuktikan visual relevan dengan narasi."]
    if problems:
        out += ["", "## Masalah yang harus diperbaiki", ""] + [f"- {p}" for p in problems]
    return "\n".join(out) + "\n"

def main():
    ap = argparse.ArgumentParser(description="QC cakupan visual narasi -> aset")
    ap.add_argument("--plan", required=True, help="coverage.json (daftar bagian narasi + aset)")
    ap.add_argument("--out", help="tulis laporan markdown ke berkas ini")
    ap.add_argument("--assets-dir", default=".", help="direktori aset relatif (default: .)")
    ap.add_argument("--json", action="store_true", help="cetak hasil sebagai JSON")
    a = ap.parse_args()
    plan = json.load(open(a.plan))
    rows, problems = evaluate(plan, a.assets_dir)
    md = to_markdown(plan, rows, problems, a.assets_dir)
    if a.out:
        open(a.out, "w").write(md)
    if a.json:
        print(json.dumps({"rows": rows, "problems": problems}, ensure_ascii=False, indent=1))
    else:
        print(md)
    sys.exit(1 if problems else 0)

if __name__ == "__main__":
    main()
