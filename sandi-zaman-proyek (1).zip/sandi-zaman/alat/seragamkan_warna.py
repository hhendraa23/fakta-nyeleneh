#!/usr/bin/env python3
"""seragamkan_warna.py — penyeragaman warna aset Sandi Zaman (lokal, Rp0).

Menambah (tidak mengubah) Standar Visual v4: gambar berwarna diubah ke sepia
lembut agar sebanding dengan foto arsip. Foto yang sudah B/W isinya TIDAK diubah,
tetapi tetap DISALIN ke --outdir supaya satu folder hasil berisi SEMUA aset
(glob "outdir/*" aman dipakai build_short.py). Sumber tidak pernah ditimpa.
Orientasi EXIF diterapkan agar foto kamera tidak tampil miring.

Contoh:
  python3 seragamkan_warna.py --indir /tmp/sz_ep/images --outdir /tmp/sz_ep/seragam \
      --log /tmp/sz_ep/warna.json --credit-log /tmp/sz_ep/warna.md

status per berkas: dikonversi | sudah_bw | gagal
Exit code: 0 = semua berhasil, 1 = ada yang gagal, 2 = tidak ada gambar.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys

from PIL import Image, ImageOps, ImageStat

EXTS = {".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp"}
BW_SATURATION_MAX = 0.02  # di bawah ini dianggap sudah hitam-putih / netral
EXIF_ORIENTATION = 0x0112


def mean_saturation(im: Image.Image) -> float:
    """Rata-rata saturasi (0..1) memakai HSV."""
    hsv = im.convert("RGB").convert("HSV")
    return ImageStat.Stat(hsv.split()[1]).mean[0] / 255.0


def to_sepia(im: Image.Image, black: str, white: str) -> Image.Image:
    alpha = im.getchannel("A") if im.mode in ("RGBA", "LA") else None
    gray = ImageOps.grayscale(im.convert("RGB"))
    out = ImageOps.colorize(gray, black=black, white=white).convert("RGB")
    if alpha is not None:
        out.putalpha(alpha)
    return out


def save_image(im: Image.Image, path: str, ext: str) -> None:
    kw = {"quality": 95, "subsampling": 0} if ext in (".jpg", ".jpeg") else {}
    if ext in (".jpg", ".jpeg") and im.mode not in ("RGB", "L"):
        im = im.convert("RGB")
    im.save(path, **kw)


def collect(indir: str, files: list[str]) -> list[str]:
    if files:
        return [f for f in files if os.path.isfile(f)]
    return [os.path.join(indir, n) for n in sorted(os.listdir(indir))
            if os.path.splitext(n)[1].lower() in EXTS]


def main() -> int:
    ap = argparse.ArgumentParser(description="Seragamkan warna aset ke sepia lembut (lokal, gratis).")
    ap.add_argument("--indir", default=".", help="direktori aset sumber")
    ap.add_argument("files", nargs="*", help="berkas tertentu (opsional; default semua di --indir)")
    ap.add_argument("--outdir", required=True, help="direktori hasil (sumber tidak ditimpa)")
    ap.add_argument("--black", default="#2b1d10", help="warna gelap sepia")
    ap.add_argument("--white", default="#f1e2c4", help="warna terang sepia")
    ap.add_argument("--bw-threshold", type=float, default=BW_SATURATION_MAX,
                    help="ambang saturasi dianggap sudah B/W (default 0.02)")
    ap.add_argument("--log", help="berkas JSON ringkasan (untuk metadata/QC)")
    ap.add_argument("--credit-log", help="berkas Markdown catatan perubahan untuk kredit")
    args = ap.parse_args()

    srcs = collect(args.indir, args.files)
    if not srcs:
        print("Tidak ada berkas gambar ditemukan.", file=sys.stderr)
        return 2

    os.makedirs(args.outdir, exist_ok=True)
    root = os.path.abspath(args.indir)
    results = []

    for src in srcs:
        rel = os.path.relpath(os.path.abspath(src), root)
        # berkas di luar --indir: jangan biarkan jalur keluar dari --outdir
        rel_dir = "" if rel.startswith("..") else os.path.dirname(rel)
        stem, ext = os.path.splitext(os.path.basename(rel))
        ext = ext.lower()
        out_dir = os.path.join(args.outdir, rel_dir)
        try:
            with Image.open(src) as im0:
                im0.load()
                oriented = im0.getexif().get(EXIF_ORIENTATION, 1) not in (0, 1)
                im = ImageOps.exif_transpose(im0)
                sat = mean_saturation(im)
                os.makedirs(out_dir, exist_ok=True)
                if sat <= args.bw_threshold:
                    status = "sudah_bw"
                    out_path = os.path.join(out_dir, stem + ext)
                    if oriented:
                        save_image(im, out_path, ext)
                        note = "isi tidak diubah selain rotasi sesuai EXIF"
                    else:
                        if os.path.abspath(out_path) != os.path.abspath(src):
                            shutil.copy2(src, out_path)
                        note = "tidak diubah (sudah hitam-putih), disalin"
                else:
                    status = "dikonversi"
                    out_path = os.path.join(out_dir, f"{stem}_sepia{ext}")
                    save_image(to_sepia(im, args.black, args.white), out_path, ext)
                    note = "konversi sepia"
        except Exception as exc:
            results.append({"source": src, "output": None, "status": "gagal",
                            "perubahan": None, "saturasi_awal": None, "catatan": str(exc)})
            print(f"GAGAL  {rel}: {exc}")
            continue

        results.append({"source": src, "output": out_path, "status": status,
                        "perubahan": "konversi sepia" if status == "dikonversi" else None,
                        "saturasi_awal": round(sat, 4), "catatan": note})
        print(f"{'SEPIA ' if status == 'dikonversi' else 'B/W   '} {rel} "
              f"(saturasi awal {sat:.3f}) -> {out_path}")

    count = lambda s: sum(1 for r in results if r["status"] == s)
    summary = {"indir": root, "outdir": os.path.abspath(args.outdir),
               "black": args.black, "white": args.white, "total": len(results),
               "dikonversi": count("dikonversi"), "sudah_bw": count("sudah_bw"),
               "gagal": count("gagal"), "files": results}

    if args.log:
        with open(args.log, "w", encoding="utf-8") as fh:
            json.dump(summary, fh, ensure_ascii=False, indent=2)

    if args.credit_log:
        lines = ["# Catatan perubahan warna (otomatis)", "",
                 f"Ambang B/W: saturasi <= {args.bw_threshold}; sepia {args.black} → {args.white}", ""]
        for r in results:
            if r["status"] == "dikonversi":
                lines.append(f"- `{os.path.basename(r['source'])}` → `{os.path.basename(r['output'])}` — perubahan: konversi sepia")
        if summary["dikonversi"] == 0:
            lines.append("- tidak ada berkas yang perlu dikonversi (semua sudah B/W)")
        with open(args.credit_log, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + "\n")

    print(json.dumps({k: summary[k] for k in ("total", "dikonversi", "sudah_bw", "gagal")}))
    return 1 if summary["gagal"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
