#!/usr/bin/env python3
"""Periksa berkas Short sebelum diserahkan ke pengguna — 100% ffprobe + PIL, biaya Rp0.

Cek wajib:
  - resolusi 1080x1920, rasio 9:16, fps 30, ada audio, durasi target
  - tidak ada stream subtitle lunak (hardsub diperiksa manual: baca 2-3 frame)

Cek standar visual lama (v3/v4) — hanya untuk render lawas:
  - `--expect-static-bg`   : latar belakang benar-benar diam (pita tepi kiri/kanan
    identik antar frame) dan margin latar terlihat (bukan gambar penuh kanvas)
  - `--expect-card-motion`: hanya area kartu yang bergerak (kartu berubah antar frame)
  - `--expect-entry-motion`: kartu benar-benar MASUK dari luar arah kanvas pada awal
    video (posisi kartu berubah besar antara frame awal dan frame setelah animasi masuk),
    bukan muncul mendadak di tengah

Cek standar v5 (default produksi sekarang) — pakai ini untuk semua render baru:
  - `--expect-fullbleed`   : konten kolase mengisi tepi kanvas (bukan gambar kecil di
    tengah dengan kertas kosong luas). Diukur dari kepadatan tepi (Laplacian) frame tengah;
    ambang sengaja longgar — 4 frame tetap wajib diperiksa manual.
  - `--expect-camera-motion`: kamera bergerak halus (zoom/pan) -> pita tepi berubah antar
    frame. Kebalikan dari `--expect-static-bg`.
  Jangan gabungkan `--expect-fullbleed` dengan `--expect-static-bg`; keduanya saling bertentangan.

Pemakaian:
  python3 verify_short.py /tmp/sz_ep/ep10.mp4 --min 40 --max 300 --expect-no-subs \
      --expect-static-bg --expect-card-motion --expect-entry-motion
  python3 verify_short.py video.mp4 --json

Keluar kode 1 bila ada kegagalan -> jangan pernah klaim "render berhasil".
"""
import argparse, json, os, subprocess, sys, tempfile, shutil


def ffprobe_json(path):
    p = subprocess.run(
        ["ffprobe", "-v", "error", "-print_format", "json",
         "-show_format", "-show_streams", path],
        capture_output=True, text=True)
    if p.returncode != 0:
        raise SystemExit(f"[gagal] ffprobe tidak bisa membaca {path}\n{p.stderr[-800:]}")
    return json.loads(p.stdout or "{}")


def parse_fps(rate):
    if not rate or "/" not in str(rate):
        try:
            return float(rate or 0)
        except ValueError:
            return 0.0
    a, b = str(rate).split("/")
    try:
        b = float(b)
        return float(a) / b if b else 0.0
    except ValueError:
        return 0.0


def grab(path, t, dst):
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", str(t), "-i", path,
                    "-frames:v", "1", dst], capture_output=True, text=True)
    return os.path.exists(dst)


def sample_frames(path, dur, n=3):
    """Ambil n frame PNG ke folder sementara (gratis, ffmpeg lokal)."""
    tmp = tempfile.mkdtemp(prefix="szqc_")
    out = []
    ts = [round(dur * (i + 1) / (n + 1), 2) for i in range(n)]
    for i, t in enumerate(ts):
        f = os.path.join(tmp, f"f{i}.png")
        if grab(path, t, f):
            out.append(f)
    return tmp, out


def card_bbox_diff(a, b):
    """Selisih maksimum pada area kartu (tengah kanvas)."""
    h, w, _ = a.shape
    card = (slice(int(h * 0.35), int(h * 0.65)), slice(int(w * 0.30), int(w * 0.70)))
    return int(abs(a[card] - b[card]).max())


def entry_check(path, dur):
    """Kartu harus bergerak masuk dari luar kanvas di awal video."""
    import numpy as np
    from PIL import Image
    tmp = tempfile.mkdtemp(prefix="szent_")
    try:
        f0 = os.path.join(tmp, "a.png")
        f1 = os.path.join(tmp, "b.png")
        if not (grab(path, 0.05, f0) and grab(path, min(1.4, max(0.6, dur * 0.4)), f1)):
            return None
        a = np.asarray(Image.open(f0).convert("RGB")).astype("int16")
        b = np.asarray(Image.open(f1).convert("RGB")).astype("int16")
        h, w, _ = a.shape
        # pita horizontal/vertikal yang tidak disentuh zoom halus, tetapi berubah
        # besar bila kartu benar-benar bergeser masuk
        band = (slice(int(h * 0.30), int(h * 0.70)), slice(int(w * 0.02), int(w * 0.28)))
        d = int(np.abs(a[band] - b[band]).mean())
        # di frame sangat awal, sebagian kanvas harus masih berupa latar kosong:
        # selisih antar-kolom rendah pada sisi masuk, tinggi setelah kartu tiba
        return {"diff": d, "ok": d >= 6}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def visual_checks(path, dur, entry=False):
    """Kembalikan list hasil cek visual; butuh numpy + PIL."""
    try:
        import numpy as np
        from PIL import Image
    except Exception:
        return [], "numpy/PIL tidak tersedia — cek visual dilewati"

    tmp, frames = sample_frames(path, dur, 3)
    try:
        if len(frames) < 2:
            return [], "frame tidak bisa diambil"
        arrs = [np.asarray(Image.open(f).convert("RGB")).astype("int16") for f in frames]
        h, w, _ = arrs[0].shape
        # pita tepi yang dijamin berada di luar kartu (margin latar)
        left = (slice(200, h - 200), slice(0, 60))
        right = (slice(400, h - 200), slice(w - 60, w))
        card = (slice(int(h * 0.40), int(h * 0.60)), slice(int(w * 0.35), int(w * 0.65)))

        # turunkan resolusi 8x untuk meredam noise kompresi H.264 (terutama pada
        # latar bertekstur rapat seperti peta/etsa) agar yang terukur hanya
        # gerakan nyata, bukan artefak encoding.
        ds = [a.reshape(h // 8, 8, w // 8, 8, 3).mean(axis=(1, 3)) for a in arrs]
        hd, wd = ds[0].shape[0], ds[0].shape[1]
        dleft = (slice(50, hd - 50), slice(0, 15))
        dright = (slice(100, hd - 50), slice(wd - 15, wd))

        # latar diam: cari pasangan frame yang paling mirip di pita tepi.
        # Latar statis selalu menyisakan minimal satu pasangan frame yang pitanya
        # identik (keduanya tidak sedang dilewati kartu), apa pun warnanya.
        bg_diff = None
        for i in range(len(ds)):
            for j in range(i + 1, len(ds)):
                d = max(int(np.abs(ds[i][dleft] - ds[j][dleft]).max()),
                        int(np.abs(ds[i][dright] - ds[j][dright]).max()))
                bg_diff = d if bg_diff is None else min(bg_diff, d)
        bg_diff = int(bg_diff or 0)

        # margin: sudut kanvas tidak pernah tersentuh kartu 74% x 56%.
        # Bila sudut ikut berubah antar adegan, berarti gambar memenuhi kanvas.
        cd = 10
        corners = [(slice(0, cd), slice(0, cd)), (slice(0, cd), slice(wd - cd, wd)),
                   (slice(hd - cd, hd), slice(0, cd)), (slice(hd - cd, hd), slice(wd - cd, wd))]
        corner_diff = max(
            max(int(np.abs(ds[i][c] - ds[j][c]).max()) for c in corners)
            for i in range(len(ds)) for j in range(i + 1, len(ds)))

        card_diff = max(card_bbox_diff(arrs[0], a) for a in arrs[1:])

        # ---- metrik v5: gerak kamera + kepadatan tepi (penuh layar) ----
        band = 10  # 10% tepi luar (pada grid 1/8 resolusi)
        edge = [(slice(0, hd), slice(0, band)), (slice(0, hd), slice(wd - band, wd)),
                (slice(0, band), slice(0, wd)), (slice(hd - band, hd), slice(0, wd))]
        edge_motion = 0
        for i in range(len(ds)):
            for j in range(i + 1, len(ds)):
                for e in edge:
                    edge_motion = max(edge_motion,
                                      int(round(float(np.abs(ds[i][e] - ds[j][e]).mean()) * 10)))
        # kepadatan tepi: rata-rata gradien pada 8% tepi frame tengah
        mid = ds[len(ds) // 2]
        gy = np.abs(np.diff(mid.mean(axis=2), axis=0))
        gx = np.abs(np.diff(mid.mean(axis=2), axis=1))
        bh, bw = max(1, int(hd * 0.08)), max(1, int(wd * 0.08))
        border_ink = float(np.concatenate([
            gy[:bh].ravel(), gy[-bh:].ravel(), gx[:, :bw].ravel(), gx[:, -bw:].ravel()]).mean())

        checks = [
            {"check": "latar belakang diam (pita tepi identik)", "ok": bg_diff <= 8,
             "detail": f"selisih piksel terkecil antar frame {bg_diff} (toleransi 8)"},
            {"check": "margin latar terlihat (sudut kanvas statis)", "ok": corner_diff <= 6,
             "detail": f"selisih piksel sudut {corner_diff} (toleransi 6)"},
            {"check": "hanya kartu yang bergerak", "ok": card_diff > 8,
             "detail": f"selisih piksel area kartu {card_diff} (>8)"},
            {"check": "komposisi penuh layar (tepi kanvas berisi kolase)",
             "ok": border_ink >= 1.5,
             "detail": f"kepadatan tepi {border_ink:.2f} (>=1.5; periksa manual 4 frame)"},
            {"check": "kamera bergerak halus (zoom/pan)", "ok": edge_motion >= 3,
             "detail": f"perubahan pita tepi {edge_motion / 10:.1f} (>=3.0)"},
        ]
        if entry:
            e = entry_check(path, dur)
            if e is None:
                checks.append({"check": "kartu masuk dari luar kanvas", "ok": False,
                               "detail": "frame awal tidak bisa diambil"})
            else:
                checks.append({"check": "kartu masuk dari luar kanvas", "ok": e["ok"],
                               "detail": f"pergeseran awal {e['diff']} (>=6)"})
        return checks, None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--min", type=float, default=0.0, help="durasi minimum (detik)")
    ap.add_argument("--max", type=float, default=1e6, help="durasi maksimum (detik)")
    ap.add_argument("--expect-no-subs", action="store_true",
                    help="gagal bila masih ada stream subtitle di dalam berkas")
    ap.add_argument("--expect-subs", action="store_true",
                    help="gagal bila tidak ada stream subtitle lunak")
    ap.add_argument("--expect-static-bg", action="store_true",
                    help="cek latar diam + margin latar terlihat (standar terkunci)")
    ap.add_argument("--expect-card-motion", action="store_true",
                    help="cek hanya kartu utama yang bergerak")
    ap.add_argument("--expect-entry-motion", action="store_true",
                    help="cek kartu masuk dari luar arah kanvas (animasi masuk, gaya lama)")
    ap.add_argument("--expect-fullbleed", action="store_true",
                    help="v5: cek komposisi mengisi tepi kanvas (bukan kartu kecil di tengah)")
    ap.add_argument("--expect-camera-motion", action="store_true",
                    help="v5: cek kamera bergerak halus (zoom/pan)")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    if not os.path.exists(args.path):
        raise SystemExit(f"[gagal] berkas tidak ada: {args.path}")
    size = os.path.getsize(args.path)
    if size < 50_000:
        raise SystemExit(f"[gagal] berkas terlalu kecil ({size} byte) — kemungkinan render tidak selesai")

    info = ffprobe_json(args.path)
    fmt = info.get("format", {})
    streams = info.get("streams", [])
    video = next((s for s in streams if s.get("codec_type") == "video"), None)
    audio = next((s for s in streams if s.get("codec_type") == "audio"), None)
    subs = [s for s in streams if s.get("codec_type") == "subtitle"]

    dur = float(fmt.get("duration") or (video or {}).get("duration") or 0)
    res = f"{video.get('width')}x{video.get('height')}" if video else "tidak ada"
    fps = round(parse_fps((video or {}).get("avg_frame_rate") or (video or {}).get("r_frame_rate")), 2)
    w = int((video or {}).get("width") or 0)
    h = int((video or {}).get("height") or 0)

    checks = []

    def cek(nama, ok, detail):
        checks.append({"check": nama, "ok": bool(ok), "detail": detail})

    cek("ada stream video", video is not None, res)
    cek("ada stream audio", audio is not None,
        f"{audio.get('codec_name')}/{audio.get('sample_rate')}Hz" if audio else "tidak ada audio")
    cek("resolusi 1080x1920", res == "1080x1920", res)
    cek("vertikal 9:16", h > w and abs((w / h) - (9 / 16)) < 0.02 if h and w else False, f"{w}x{h}")
    cek("fps 30", abs(fps - 30) < 0.6, f"{fps} fps")
    cek(f"durasi {args.min:g}-{args.max:g} s", args.min <= dur <= args.max, f"{dur:.2f} s")
    if args.expect_no_subs:
        cek("tanpa subtitle lunak", not subs, f"{len(subs)} stream subtitle")
    if args.expect_subs:
        cek("punya subtitle lunak", bool(subs), f"{len(subs)} stream subtitle")

    note = None
    if (args.expect_static_bg or args.expect_card_motion or args.expect_entry_motion
            or args.expect_fullbleed or args.expect_camera_motion):
        vis, note = visual_checks(args.path, dur, entry=args.expect_entry_motion)
        for c in vis:
            n = c["check"]
            if n.startswith("margin") and not args.expect_static_bg:
                continue
            if n.startswith("hanya kartu") and not args.expect_card_motion:
                continue
            if n.startswith("kartu masuk") and not args.expect_entry_motion:
                continue
            if n.startswith("komposisi penuh") and not args.expect_fullbleed:
                continue
            if n.startswith("kamera bergerak") and not args.expect_camera_motion:
                continue
            checks.append(c)

    report = {
        "file": os.path.abspath(args.path),
        "bytes": size,
        "duration_sec": round(dur, 2),
        "resolution": res,
        "fps": fps,
        "video_codec": (video or {}).get("codec_name"),
        "audio_codec": (audio or {}).get("codec_name"),
        "soft_subtitle_streams": len(subs),
        "checks": checks,
        "ok": all(c["ok"] for c in checks),
    }
    if note:
        report["note"] = note

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(f"Berkas : {report['file']}  ({size/1_048_576:.1f} MB)")
        print(f"Durasi : {dur:.2f} s   Resolusi: {res}   fps: {fps}   audio: {report['audio_codec']}")
        print(f"Subtile lunak di dalam berkas: {len(subs)}")
        for c in checks:
            print(("  OK   " if c["ok"] else "  GAGAL") + f" — {c['check']} ({c['detail']})")
        if note:
            print(f"  catatan: {note}")
        print("\nHASIL: " + ("LULUS — berkas boleh diserahkan." if report["ok"]
                             else "TIDAK LULUS — perbaiki dulu, jangan klaim render berhasil."))
    sys.exit(0 if report["ok"] else 1)


if __name__ == "__main__":
    main()
