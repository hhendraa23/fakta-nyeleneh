#!/usr/bin/env python3
"""build_collage_v5.py — renderer kolase scrapbook v5 (Standar Visual Sandi Zaman v5).

Menyusun frame penuh 1080x1920 dari *scene plan* JSON (lihat `panduan-komposisi-v5.md`):
kertas krem bertekstur, foto arsip B/W bertepi sobek bertumpuk, objek utama berwarna,
anotasi tangan merah, label kraft, catatan kaki, kredit, dan logo. Lalu ffmpeg memberi
gerak halus (zoom/pan + objek masuk-settle) dan menyambung audio.

100% lokal (PIL + ffmpeg), tanpa jaringan, tanpa kredit berbayar.

Pemakaian:
  python3 build_collage_v5.py --plan plan.json --audio narasi.mp3 --out ep.mp4 \
      --logo brand_logo_sandi_zaman.png --credit-line "Foto: ... (CC BY-SA 4.0)"
  python3 build_collage_v5.py --plan plan.json --audio narasi.mp3 --frames-only --out /tmp/pratinjau

CATATAN: versi ini diserahkan tanpa render uji (permintaan pengguna: tunggu persetujuan).
Uji pertama yang disarankan: `--frames-only` pada 1 beat, periksa PNG, lalu render 5 detik.
"""
import argparse
import json
import math
import os
import random
import shutil
import subprocess
import sys
import tempfile

from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps

W, H, FPS = 1080, 1920, 30
RED = (179, 32, 42)
RED_DARK = (143, 22, 32)
INK = (43, 38, 32)
INK_SOFT = (91, 78, 60)
PAPER = (233, 225, 206)
KRAFT = (201, 176, 138)

FONT_MONO_B = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"
FONT_MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
FONT_SERIF_B = "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf"
FONT_SANS = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"

SAFE = 0.06  # area aman tepi (fraksi)


# --------------------------------------------------------------------------
# utilitas
# --------------------------------------------------------------------------
def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        raise SystemExit("[gagal] " + " ".join(cmd[:6]) + f"\n{p.stderr[-1200:]}")
    return p


def die(msg):
    raise SystemExit(f"[tolak] {msg}")


def font(path, size):
    return ImageFont.truetype(path, max(8, int(size)))


def dilate(alpha, radius):
    """Dilatasi topeng alpha (untuk outline stiker) — blur+threshold, cepat."""
    r = max(1.0, float(radius))
    b = alpha.filter(ImageFilter.GaussianBlur(r * 0.55))
    return b.point(lambda v: 255 if v >= 38 else 0)


def paper_texture(size, seed=7):
    """Kertas krem tua: serat, bintik, lipatan samar. Penuh kanvas."""
    w, h = size
    rnd = random.Random(seed)
    base = Image.new("RGB", size, PAPER)
    px = base.load()
    for _ in range(int(w * h / 60)):
        x, y = rnd.randrange(w), rnd.randrange(h)
        d = rnd.randint(-11, 9)
        r, g, b = px[x, y]
        px[x, y] = (max(0, min(255, r + d)), max(0, min(255, g + d)), max(0, min(255, b + d)))
    img = base.filter(ImageFilter.GaussianBlur(0.5))
    d = ImageDraw.Draw(img, "RGBA")
    # serat mendatar & lipatan
    for _ in range(120):
        y = rnd.randrange(h)
        d.line([(0, y), (w, y + rnd.randint(-5, 5))],
               fill=(150, 124, 84, rnd.randint(4, 12)), width=rnd.randint(1, 3))
    for _ in range(18):
        x = rnd.randrange(w)
        d.line([(x, 0), (x + rnd.randint(-40, 40), h)],
               fill=(255, 250, 235, rnd.randint(3, 8)), width=rnd.randint(2, 5))
    for _ in range(26):
        cx, cy = rnd.randrange(w), rnd.randrange(h)
        rr = rnd.randint(30, 150)
        d.ellipse([cx - rr, cy - rr // 2, cx + rr, cy + rr // 2],
                  fill=(148, 120, 78, rnd.randint(3, 8)))
    # vignette sangat halus (bukan bingkai)
    vig = Image.new("L", size, 0)
    ImageDraw.Draw(vig).ellipse([-w // 4, -h // 6, w + w // 4, h + h // 6], fill=255)
    vig = vig.filter(ImageFilter.GaussianBlur(220))
    dark = Image.new("RGB", size, (196, 184, 158))
    return Image.composite(img, dark, vig)


def torn_mask(size, seed, jitter=None):
    """Tepi sobek tidak beraturan (poligon bergerigi)."""
    w, h = size
    rnd = random.Random(seed)
    j = int(jitter if jitter is not None else max(4, min(w, h) * 0.022))
    pts = []
    step = max(16, min(w, h) // 12)
    x = 0
    while x < w:
        pts.append((x, rnd.randint(0, j)))
        x += rnd.randint(step // 2, step)
    y = 0
    while y < h:
        pts.append((w - 1 - rnd.randint(0, j), y))
        y += rnd.randint(step // 2, step)
    x = w
    while x > 0:
        pts.append((x, h - 1 - rnd.randint(0, j)))
        x -= rnd.randint(step // 2, step)
    y = h
    while y > 0:
        pts.append((rnd.randint(0, j), y))
        y -= rnd.randint(step // 2, step)
    m = Image.new("L", size, 0)
    ImageDraw.Draw(m).polygon(pts, fill=255)
    return m.filter(ImageFilter.GaussianBlur(1.0))


def bwrgb(im):
    """Foto arsip: hitam-putih lembut (bukan sepia pekat)."""
    g = ImageEnhance.Contrast(im.convert("L")).enhance(1.08)
    return Image.merge("RGB", (
        g.point(lambda v: min(255, int(v * 1.02 + 6))),
        g.point(lambda v: min(255, int(v * 0.99 + 4))),
        g.point(lambda v: min(255, int(v * 0.94 + 2))),
    ))


def shadowed(tile, blur=16, off=(10, 14), strength=150):
    pad = int(blur * 2.6) + max(off)
    c = Image.new("RGBA", (tile.width + 2 * pad, tile.height + 2 * pad), (0, 0, 0, 0))
    sh = Image.new("L", c.size, 0)
    sh.paste(tile.split()[-1], (pad + off[0], pad + off[1]))
    sh = sh.filter(ImageFilter.GaussianBlur(blur)).point(lambda v: int(v * strength / 255))
    s = Image.new("RGBA", c.size, (38, 28, 16, 255))
    s.putalpha(sh)
    c.alpha_composite(s)
    c.alpha_composite(tile, (pad, pad))
    return c


def paste_center(canvas, im, cx, cy, rot=0.0):
    if abs(rot) > 0.01:
        im = im.rotate(rot, expand=True, resample=Image.BICUBIC)
    x = int(cx - im.width / 2)
    y = int(cy - im.height / 2)
    canvas.alpha_composite(im, (x, y))


# --------------------------------------------------------------------------
# elemen
# --------------------------------------------------------------------------
def resolve(src, base_dir):
    p = src if os.path.isabs(src) else os.path.join(base_dir, src)
    if not os.path.exists(p):
        die(f"berkas tidak ditemukan: {src}")
    return p


def photo_tile(spec, base_dir, seed):
    src = resolve(spec["src"], base_dir)
    tw = max(40, int(float(spec["w"]) * W))
    th = max(40, int(float(spec["h"]) * H))
    im = ImageOps.exif_transpose(Image.open(src)).convert("RGB")
    if spec.get("bw", True) and spec.get("kind") != "warna":
        im = bwrgb(im)
    margin = max(6, int(min(tw, th) * 0.028))
    iw, ih = max(20, tw - 2 * margin), max(20, th - 2 * margin)
    s = max(iw / im.width, ih / im.height)
    im = im.resize((max(iw, int(im.width * s + 0.5)), max(ih, int(im.height * s + 0.5))),
                   Image.LANCZOS)
    l, t = (im.width - iw) // 2, (im.height - ih) // 2
    im = im.crop((l, t, l + iw, t + ih))

    tile = Image.new("RGBA", (tw, th), (245, 238, 224, 255))
    if spec.get("torn", True):
        mask = torn_mask((iw, ih), seed)
    else:
        mask = Image.new("L", (iw, ih), 255)
        ImageDraw.Draw(mask).rectangle([0, 0, iw - 1, ih - 1], outline=0, width=1)
        mask = mask.filter(ImageFilter.GaussianBlur(0.6))
    ph = im.convert("RGBA")
    ph.putalpha(mask)
    tile.alpha_composite(ph, (margin, margin))
    d = ImageDraw.Draw(tile, "RGBA")
    d.rectangle([0, 0, tw - 1, th - 1], outline=(122, 104, 78, 70), width=2)
    if spec.get("kind") == "dokumen":
        d.rectangle([margin // 2, margin // 2, tw - margin // 2, th - margin // 2],
                    outline=(150, 128, 96, 110), width=1)
    return shadowed(tile, blur=13, off=(8, 12), strength=140)


def cutout_layer(spec, base_dir):
    """Objek utama berwarna: outline putih + garis merah + bayangan, di kanvas transparan."""
    src = resolve(spec["src"], base_dir)
    im = Image.open(src).convert("RGBA")
    bbox = im.split()[-1].getbbox()
    if not bbox:
        die(f"cutout tanpa piksel terlihat: {spec['src']}")
    im = im.crop(bbox)
    tw = max(60, int(float(spec["w"]) * W))
    s = tw / im.width
    im = im.resize((tw, max(1, int(im.height * s))), Image.LANCZOS)
    a = im.split()[-1].point(lambda v: 255 if v > 26 else 0)
    im.putalpha(a)

    pad = max(20, tw // 14)
    size = (im.width + 2 * pad, im.height + 2 * pad)
    layer = Image.new("RGBA", size, (0, 0, 0, 0))
    red = Image.new("RGBA", size, RED + (205,))
    white = Image.new("RGBA", size, (247, 242, 230, 255))
    if spec.get("outline", True):
        red.putalpha(dilate(_centered(a, size, pad), max(10, tw // 30)))
        white.putalpha(dilate(_centered(a, size, pad), max(6, tw // 55)))
        layer.alpha_composite(red)
        layer.alpha_composite(white)
    sh = Image.new("L", size, 0)
    sh.paste(a, (pad, pad))
    sh = sh.filter(ImageFilter.GaussianBlur(w2px(im.width) * 0.03 + 8)).point(lambda v: int(v * 0.45))
    sld = Image.new("RGBA", size, (40, 30, 18, 255))
    sld.putalpha(sh)
    layer.alpha_composite(sld)
    layer.alpha_composite(im, (pad, pad))

    canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    paste_center(canvas, layer, float(spec["x"]) * W, float(spec["y"]) * H,
                 float(spec.get("rot", 0)))
    return canvas


def w2px(v):
    return max(1.0, float(v))


def _centered(alpha, size, pad):
    c = Image.new("L", size, 0)
    c.paste(alpha, (pad, pad))
    return c


# --------------------------------------------------------------------------
# anotasi tangan merah
# --------------------------------------------------------------------------
def draw_circle(d, cx, cy, rx, ry, rot_deg, seed, width=7):
    rnd = random.Random(seed)
    rad = math.radians(rot_deg)
    for p in range(2):
        start = rnd.uniform(-1.1, 0.5)
        sweep = rnd.uniform(5.7, 6.5)
        n = 140
        pts = []
        for i in range(n + 1):
            ang = start + sweep * i / n
            wob = 1.0 + 0.05 * rnd.uniform(-1, 1)
            rr = (1.0 - 0.04 * p)
            x, y = rx * rr * wob * math.cos(ang), ry * rr * wob * math.sin(ang)
            pts.append((cx + x * math.cos(rad) - y * math.sin(rad),
                        cy + x * math.sin(rad) + y * math.cos(rad)))
        d.line(pts, fill=RED + (205 - p * 25,), width=max(3, width - p * 2), joint="curve")


def draw_arrow(d, x1, y1, x2, y2, seed, width=7):
    rnd = random.Random(seed)
    dx, dy = x2 - x1, y2 - y1
    dist = max(1.0, math.hypot(dx, dy))
    nx, ny = -dy / dist, dx / dist
    bow = rnd.uniform(-0.10, 0.10) * dist
    mx, my = (x1 + x2) / 2 + nx * bow, (y1 + y2) / 2 + ny * bow
    pts = []
    for i in range(41):
        t = i / 40
        # bezier kuadratik + gemetar
        px = (1 - t) ** 2 * x1 + 2 * (1 - t) * t * mx + t * t * x2
        py = (1 - t) ** 2 * y1 + 2 * (1 - t) * t * my + t * t * y2
        pts.append((px + rnd.uniform(-1.4, 1.4), py + rnd.uniform(-1.4, 1.4)))
    d.line(pts, fill=RED + (215,), width=width, joint="curve")
    ang = math.atan2(y2 - my, x2 - mx)
    for da in (0.42, -0.42):
        ax = x2 - math.cos(ang + da) * dist * 0.16
        ay = y2 - math.sin(ang + da) * dist * 0.16
        d.line([(x2, y2), (ax, ay)], fill=RED + (215,), width=width)


def draw_year(canvas, spec):
    size = int(float(spec.get("size", 0.085)) * H)
    f = font(FONT_SERIF_B, size)
    txt = str(spec["text"])
    tmp = Image.new("RGBA", (int(f.getlength(txt)) + 40, size * 2), (0, 0, 0, 0))
    ImageDraw.Draw(tmp).text((20, 10), txt, font=f, fill=RED + (235,))
    paste_center(canvas, tmp, float(spec["x"]) * W, float(spec["y"]) * H,
                 float(spec.get("rot", 0)))


def draw_note(canvas, spec):
    size = int(float(spec.get("size", 0.020)) * H)
    f = font(FONT_MONO_B, size)
    txt = str(spec["text"]).upper()
    lines = txt.split("\n")
    lh = int(size * 1.35)
    wid = int(max(f.getlength(l) for l in lines)) + 24
    tmp = Image.new("RGBA", (wid, lh * len(lines) + 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(tmp)
    for i, l in enumerate(lines):
        d.text((12, 6 + i * lh), l, font=f, fill=INK + (238,))
    paste_center(canvas, tmp, float(spec["x"]) * W, float(spec["y"]) * H,
                 float(spec.get("rot", 0)))


def draw_underline(d, spec, seed):
    rnd = random.Random(seed)
    x = float(spec["x"]) * W
    y = float(spec["y"]) * H
    w = float(spec.get("w", 0.25)) * W
    pts = []
    for i in range(13):
        t = i / 12
        pts.append((x - w / 2 + w * t, y + rnd.uniform(-2.5, 2.5)))
    d.line(pts, fill=RED + (210,), width=int(spec.get("width", 6)), joint="curve")


def tape_strip(w, h, seed):
    rnd = random.Random(seed)
    t = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(t)
    d.rectangle([0, 0, w, h], fill=KRAFT + (170,))
    for i in range(0, w, 7):
        d.line([(i, 0), (i + rnd.randint(-2, 2), h)], fill=(173, 148, 110, 45), width=1)
    d.line([(0, 0), (w, 0)], fill=(168, 142, 104, 150), width=2)
    d.line([(0, h - 1), (w, h - 1)], fill=(168, 142, 104, 150), width=2)
    return t


def draw_headline(canvas, text, seed):
    if not text:
        return
    size = int(0.030 * H)
    f = font(FONT_MONO_B, size)
    txt = text.upper()[:26]
    tw = int(f.getlength(txt))
    strip = tape_strip(tw + 64, size + 34, seed)
    d = ImageDraw.Draw(strip)
    d.text((32, 16), txt, font=f, fill=(32, 28, 24, 245))
    paste_center(canvas, strip, 0.36 * W, 0.098 * H, -1.4)


def wrap(draw, text, f, max_w):
    words = text.split()
    lines, cur = [], ""
    for wd in words:
        cand = (cur + " " + wd).strip()
        if draw.textlength(cand, font=f) <= max_w or not cur:
            cur = cand
        else:
            lines.append(cur)
            cur = wd
    if cur:
        lines.append(cur)
    return lines[:2]


def draw_caption(canvas, text, credit):
    d = ImageDraw.Draw(canvas, "RGBA")
    y = H - int(0.075 * H)
    if text:
        f = font(FONT_MONO, int(0.0155 * H))
        lines = wrap(d, text, f, int(0.84 * W))
        for i, line in enumerate(lines):
            tw = d.textlength(line, font=f)
            d.text(((W - tw) / 2, y - len(lines) * int(f.size * 1.25) + i * int(f.size * 1.25)),
                   line, font=f, fill=INK_SOFT + (240,))
    if credit:
        f = font(FONT_MONO, int(0.0125 * H))
        c = credit[:118]
        tw = d.textlength(c, font=f)
        cy = H - int(0.030 * H)
        d.rectangle([(W - tw) / 2 - 12, cy - 6, (W + tw) / 2 + 12, cy + f.size + 8],
                    fill=(233, 225, 206, 210))
        d.text(((W - tw) / 2, cy), c, font=f, fill=(88, 74, 56, 245))


# --------------------------------------------------------------------------
# beat
# --------------------------------------------------------------------------
def render_beat(beat, plan, paper, logo, credit, outdir, idx, base_dir):
    canvas = paper.copy().convert("RGBA")
    photos = beat.get("photos") or []
    if len(photos) < 2:
        die("KOMPOSISI_TERLALU_KOSONG — minimal 2 foto per beat")
    if len(beat.get("annotations") or []) > 4:
        die("ANOTASI_BERLEBIHAN — maksimal 4 anotasi per beat")
    if beat.get("headline") and len(str(beat["headline"])) > 26:
        die("TEKS_DI_LUAR_AREA_AMAN — headline maksimal 26 karakter")

    items = []
    for i, p in enumerate(photos):
        items.append((int(p.get("z", i + 1)), photo_tile(p, base_dir, 101 + idx * 17 + i),
                      float(p["x"]) * W, float(p["y"]) * H, float(p.get("rot", 0))))
    mp = beat.get("map")
    if mp:
        m = dict(mp)
        m.setdefault("kind", "peta")
        m.setdefault("w", 0.34)
        m.setdefault("h", 0.30)
        items.append((int(m.get("z", 2)), photo_tile(m, base_dir, 211 + idx),
                      float(m["x"]) * W, float(m["y"]) * H, float(m.get("rot", 0))))
    for _, tile, cx, cy, rot in sorted(items, key=lambda z: z[0]):
        paste_center(canvas, tile, cx, cy, rot)

    d = ImageDraw.Draw(canvas, "RGBA")
    for j, a in enumerate(beat.get("annotations") or []):
        t = a.get("type")
        seed = 500 + idx * 31 + j
        if t == "circle":
            draw_circle(d, float(a["x"]) * W, float(a["y"]) * H,
                        float(a.get("rx", 0.10)) * W, float(a.get("ry", 0.08)) * H,
                        float(a.get("rot", 0)), seed)
        elif t == "arrow":
            draw_arrow(d, float(a["x1"]) * W, float(a["y1"]) * H,
                       float(a["x2"]) * W, float(a["y2"]) * H, seed,
                       width=int(a.get("width", 7)))
        elif t == "year":
            draw_year(canvas, a)
        elif t == "note":
            draw_note(canvas, a)
        elif t == "underline":
            draw_underline(d, a, seed)
        else:
            die(f"ANOTASI_TIDAK_DIKENAL: {t}")

    for j, tp in enumerate(beat.get("tape") or []):
        tw = int(float(tp.get("w", 0.18)) * W)
        strip = tape_strip(tw, int(tw * 0.30), 700 + idx * 7 + j)
        paste_center(canvas, strip, float(tp["x"]) * W, float(tp["y"]) * H,
                     float(tp.get("rot", -6)))

    draw_headline(canvas, beat.get("headline"), 900 + idx)
    draw_caption(canvas, beat.get("caption"), credit)

    if logo and os.path.exists(logo):
        lg = Image.open(logo).convert("RGBA")
        lw = int(0.135 * W)
        lg = lg.resize((lw, max(1, int(lg.height * lw / lg.width))), Image.LANCZOS)
        pad = int(SAFE * W)
        canvas.alpha_composite(lg, (W - lw - pad, pad))

    base_path = os.path.join(outdir, f"beat{idx:02d}_base.png")
    canvas.convert("RGB").save(base_path)

    cut_path = None
    if beat.get("cutout"):
        cut_path = os.path.join(outdir, f"beat{idx:02d}_cut.png")
        cutout_layer(beat["cutout"], base_dir).save(cut_path)
    return base_path, cut_path


def animate_beat(base, cut, dur, out, idx):
    """Gerak halus: zoom/pan kamera + objek utama masuk lalu settle."""
    d = max(0.4, float(dur))
    if idx % 3 == 0:
        zoom = f"(1+0.05*t/{d:.3f})"
        px, py = "(iw-ow)/2", "(ih-oh)/2"
    elif idx % 3 == 1:
        zoom = f"(1.05-0.05*t/{d:.3f})"
        px = f"(iw-ow)/2+(iw-ow)*0.25*(0.5-t/{d:.3f})"
        py = "(ih-oh)/2"
    else:
        zoom = f"(1+0.04*t/{d:.3f})"
        px = "(iw-ow)/2"
        py = f"(ih-oh)/2+(ih-oh)*0.22*(0.5-t/{d:.3f})"

    vf = [
        f"[0:v]scale=w='trunc(iw*{zoom}/2)*2':h=-2:eval=frame,"
        f"crop={W}:{H}:x='{px}':y='{py}',setsar=1,format=rgba[bg]"
    ]
    inputs = ["-loop", "1", "-i", base]
    if cut:
        entry = max(0.35, min(0.75, d * 0.25))
        cy = (f"60*(1-min(t/{entry:.3f},1))+5*sin(t*0.9)")
        vf.append(f"[1:v]scale={W}:{H},setsar=1,format=rgba[cut]")
        vf.append(f"[bg][cut]overlay=x=0:y='{cy}':format=auto,format=yuv420p[v]")
        inputs += ["-loop", "1", "-i", cut]
        outmap = "[v]"
    else:
        vf.append("[bg]format=yuv420p[v]")
        outmap = "[v]"

    run(["ffmpeg", "-y", "-loglevel", "error",
         *inputs, "-t", f"{d:.3f}", "-filter_complex", ";".join(vf),
         "-map", outmap, "-r", str(FPS), "-c:v", "libx264", "-preset", "medium",
         "-crf", "20", "-pix_fmt", "yuv420p", out])


def validate(plan):
    beats = plan.get("beats") or []
    if not beats:
        die("scene plan tanpa beats")
    for i, b in enumerate(beats):
        if not b.get("dur"):
            die(f"beat {i+1} tanpa durasi")
        if len(b.get("photos") or []) < 2:
            die(f"KOMPOSISI_TERLALU_KOSONG pada beat {i+1} — minimal 2 foto")
        if len(b.get("annotations") or []) > 4:
            die(f"ANOTASI_BERLEBIHAN pada beat {i+1} — maksimal 4")
        if not (0.0 < float(b["dur"]) <= 30.0):
            die(f"durasi beat {i+1} tidak wajar: {b['dur']}")


def probe_duration(path):
    p = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=nw=1:nk=1", path])
    try:
        return float((p.stdout or "0").strip().splitlines()[0])
    except (ValueError, IndexError):
        raise SystemExit(f"tidak bisa membaca durasi audio: {path}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", required=True)
    ap.add_argument("--audio", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--logo")
    ap.add_argument("--credit-line", default="")
    ap.add_argument("--paper", help="tekstur kertas pengganti (default prosedural)")
    ap.add_argument("--loudnorm", action="store_true",
                    help="normalisasi audio akhir ke -16 LUFS / TP -1.5 dB")
    ap.add_argument("--frames-only", action="store_true",
                    help="hanya tulis PNG tiap beat (pratinjau, tanpa video)")
    args = ap.parse_args()

    with open(args.plan, encoding="utf-8") as f:
        plan = json.load(f)
    validate(plan)
    if not os.path.exists(args.audio):
        die(f"audio tidak ditemukan: {args.audio}")
    base_dir = os.path.dirname(os.path.abspath(args.plan))

    tmp = tempfile.mkdtemp(prefix="szv5_")
    paper = (ImageOps.exif_transpose(Image.open(args.paper)).convert("RGB")
             if args.paper and os.path.exists(args.paper) else paper_texture((W, H)))
    if paper.size != (W, H):
        s = max(W / paper.width, H / paper.height)
        paper = paper.resize((max(W, int(paper.width * s + 0.5)),
                              max(H, int(paper.height * s + 0.5))), Image.LANCZOS)
        l, t = (paper.width - W) // 2, (paper.height - H) // 2
        paper = paper.crop((l, t, l + W, t + H))

    audio_dur = probe_duration(args.audio)
    beats = plan["beats"]
    total = sum(float(b["dur"]) for b in beats)
    k = audio_dur / total if total > 0 else 1.0
    if abs(k - 1) > 0.01:
        print(f"[info] durasi beat diskalakan x{k:.4f} agar total = {audio_dur:.2f}s")
        for b in beats:
            b["dur"] = float(b["dur"]) * k

    segs = []
    for i, b in enumerate(beats):
        base, cut = render_beat(b, plan, paper, args.logo, args.credit_line,
                                tmp, i, base_dir)
        print(f"[beat] {i+1}/{len(beats)}  {b['dur']:.2f}s  {len(b.get('photos') or [])} foto"
              + ("  +cutout" if cut else ""))
        if args.frames_only:
            continue
        seg = os.path.join(tmp, f"s{i:02d}.mp4")
        animate_beat(base, cut, b["dur"], seg, i)
        segs.append(seg)

    if args.frames_only:
        os.makedirs(args.out, exist_ok=True)
        for f in sorted(os.listdir(tmp)):
            if f.endswith(".png"):
                shutil.copy2(os.path.join(tmp, f), os.path.join(args.out, f))
        print(f"[pratinjau] PNG beat ditulis ke {args.out} (tanpa video, tanpa audio)")
        shutil.rmtree(tmp, ignore_errors=True)
        return

    lst = os.path.join(tmp, "list.txt")
    with open(lst, "w") as f:
        for s in segs:
            f.write(f"file '{s}'\n")
    silent = os.path.join(tmp, "silent.mp4")
    run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0",
         "-i", lst, "-c", "copy", silent])

    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-i", silent, "-i", args.audio,
           "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
           "-shortest", "-movflags", "+faststart"]
    if args.loudnorm:
        cmd += ["-af", "loudnorm=I=-16:TP=-1.5:LRA=11"]
    cmd.append(args.out)
    run(cmd)
    shutil.rmtree(tmp, ignore_errors=True)
    print(f"[selesai] {args.out}  ({probe_duration(args.out):.1f}s, 1080x1920, 30fps)")


if __name__ == "__main__":
    main()
