#!/usr/bin/env python3
"""Cari + unduh ilustrasi dari Wikimedia Commons beserta metadata lisensinya.

Hanya gambar berlisensi domain publik / CC0 / CC BY / CC BY-SA yang diterima.
Gambar berlisensi NC atau ND ditolak (tidak sesuai kebutuhan YouTube monetisasi).

Pemakaian:
  python3 commons_fetch.py --queries "Kedukan Bukit inscription" "Muara Jambi" \
      --out /tmp/ep10/images --credits /tmp/ep10/credits.json --limit 4

Output: berkas gambar + credits.json berisi judul, pembuat, URL halaman,
jenis lisensi, URL lisensi, dan catatan perubahan.
"""
import argparse, json, os, re, sys, urllib.parse, urllib.request

API = "https://commons.wikimedia.org/w/api.php"
UA = "SandiZamanBot/1.0 (educational video research; contact: channel owner)"

OK_PATTERNS = [
    r"^public domain", r"^pd", r"^cc0", r"^cc[- ]by([- ]sa)?[- ]?\d",
    r"^cc[- ]by([- ]sa)?$", r"^attribution",
]
BAD_PATTERNS = [r"\bnc\b", r"non[- ]?commercial", r"\bnd\b", r"no[- ]?deriv"]


def api_get(params):
    params = dict(params)
    params.setdefault("format", "json")
    params.setdefault("formatversion", "2")
    url = API + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=45) as r:
        return json.loads(r.read().decode("utf-8"))


def license_ok(name):
    n = (name or "").strip().lower()
    if not n:
        return False
    if any(re.search(p, n) for p in BAD_PATTERNS):
        return False
    return any(re.search(p, n) for p in OK_PATTERNS)


def strip_html(s):
    s = re.sub(r"<[^>]+>", "", s or "")
    return re.sub(r"\s+", " ", s).strip()


def search(query, limit):
    data = api_get({
        "action": "query", "generator": "search",
        "gsrsearch": f"filetype:bitmap {query}", "gsrnamespace": "6",
        "gsrlimit": str(limit * 4), "prop": "imageinfo",
        "iiprop": "url|size|extmetadata|mime", "iiurlwidth": "1800",
    })
    return data.get("query", {}).get("pages", []) or []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--queries", nargs="+", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--credits", required=True)
    ap.add_argument("--limit", type=int, default=3, help="maks gambar per kueri")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    credits = []
    for q in args.queries:
        kept = 0
        for page in search(q, args.limit):
            if kept >= args.limit:
                break
            info = (page.get("imageinfo") or [{}])[0]
            if not info.get("thumburl"):
                continue
            if info.get("mime") not in ("image/jpeg", "image/png", "image/webp"):
                continue
            meta = info.get("extmetadata") or {}

            def m(key):
                return strip_html((meta.get(key) or {}).get("value", ""))

            lic = m("LicenseShortName") or m("License")
            if not license_ok(lic):
                print(f"[skip lisensi] {page.get('title')} -> {lic or 'tanpa lisensi jelas'}")
                continue
            if info.get("width", 0) < 900:
                continue

            safe = re.sub(r"[^A-Za-z0-9_-]+", "_", page["title"].replace("File:", ""))[:70]
            raw_path = urllib.parse.urlparse(info["thumburl"]).path
            ext = os.path.splitext(raw_path)[1].lower() or ".jpg"
            if ext not in (".jpg", ".jpeg", ".png", ".webp"):
                ext = ".jpg"
            fname = f"{len(credits)+1:02d}_{safe}{ext}"
            path = os.path.join(args.out, fname)
            try:
                req = urllib.request.Request(info["thumburl"], headers={"User-Agent": UA})
                with urllib.request.urlopen(req, timeout=90) as r, open(path, "wb") as f:
                    f.write(r.read())
            except Exception as e:
                print(f"[gagal unduh] {page.get('title')}: {e}")
                continue

            credits.append({
                "file": path,
                "query": q,
                "title": page["title"].replace("File:", ""),
                "author": m("Artist") or m("Credit") or "Tidak tercantum",
                "source_page": info.get("descriptionurl", ""),
                "license": lic,
                "license_url": m("LicenseUrl") or "",
                "changes": "Dipotong/diposisikan ulang, diberi nuansa sepia, dan diberi bingkai kertas.",
                "downloaded_from": info["thumburl"],
            })
            kept += 1
            print(f"[ok] {fname}  |  {lic}")

    existing = []
    if os.path.exists(args.credits):
        try:
            existing = json.load(open(args.credits))
        except Exception:
            existing = []
    allc = existing + credits
    with open(args.credits, "w") as f:
        json.dump(allc, f, ensure_ascii=False, indent=2)
    print(f"\nTotal gambar terpakai: {len(credits)} (arsip kredit: {len(allc)})")
    if not credits:
        sys.exit(2)


if __name__ == "__main__":
    main()
