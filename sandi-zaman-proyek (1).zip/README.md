# SANDI ZAMAN

Channel YouTube Shorts sejarah misteri (1080x1920, 30 fps, 50-60 detik), dibuat dengan Remotion.
Gaya visual: infografis (kartu, label, garis waktu) dipadu foto arsip hitam-putih bersobekan.
Biaya harus Rp0.

## Episode Pompeii
- Data episode: `data/pompeii.json` (7 beat, 55 detik). Komponen: `src/sandi/`.
- `npm run sz:foto`   -> satu gambar per beat di `out/sandi/` (periksa tampilan)
- `npm run sz:srt`    -> subtitle terpisah `out/pompeii.srt` (tidak dibakar ke video)
- `npm run render`    -> video `out/pompeii.mp4`
- `npm run sz:qc`     -> QC (durasi 50-60 detik, tanpa subtitle terbakar, ada gerak kamera)
- Foto arsip: taruh di `public/gambar/` lalu isi `"foto"` pada beat 2 dan 5 di JSON.
- Narasi: taruh MP3 baru di `public/narasi/` lalu isi `"audio"` di JSON.
- Tanpa Codespaces terbuka: tab Actions -> "Render Sandi Zaman Pompeii" -> Run workflow.

## Alat dan standar
Folder `sandi-zaman/` berisi alat QC, pengunduh aset Wikimedia, dan standar (visual, komposisi, narasi, suara, biaya).
Pemasangan alat Python: `bash sandi-zaman/setup.sh`.

## Arsip
Materi FAKTA NYELENEH lama (claymation dan Banjir Molase Boston 1919) ada di `arsip/fakta-nyeleneh/`.
