#!/usr/bin/env bash
# Memindahkan materi FAKTA NYELENEH lama ke arsip/fakta-nyeleneh/ (tidak menghapus apa pun).
# Jalankan SETELAH unzip. Aman dijalankan ulang.
set -e
ARSIP=arsip/fakta-nyeleneh
mkdir -p "$ARSIP"

pindah() {
  if [ -e "$1" ] && [ ! -e "$ARSIP/$1" ]; then
    mkdir -p "$ARSIP/$(dirname "$1")"
    mv "$1" "$ARSIP/$1"
    echo "dipindah: $1"
  fi
}

for f in src/FaktaVideo.tsx src/durasi.ts src/components src/scenes src/clay src/styles \
         data/fakta.json data/banjir-molase.json foto-episode.sh; do
  pindah "$f"
done

# workflow lama dinonaktifkan dengan mengganti ekstensi
if [ -e .github/workflows/render.yml ]; then
  mkdir -p "$ARSIP/.github/workflows"
  mv .github/workflows/render.yml "$ARSIP/.github/workflows/render.yml.arsip"
  echo "dipindah: .github/workflows/render.yml"
fi

echo "Selesai. Materi lama ada di $ARSIP (tidak dihapus)."
