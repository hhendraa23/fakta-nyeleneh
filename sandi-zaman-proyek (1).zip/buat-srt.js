// Membuat out/pompeii.srt dari data/pompeii.json.
// Waktu tiap kalimat DIPERKIRAKAN dari jumlah kata; sesuaikan lagi setelah narasi nyata ada.
const fs = require("fs");
const d = JSON.parse(fs.readFileSync("data/pompeii.json", "utf8"));
const p = (n, l = 2) => String(n).padStart(l, "0");
const f = (t) => {
  const ms = Math.round(t * 1000);
  return `${p(Math.floor(ms / 3600000))}:${p(Math.floor((ms % 3600000) / 60000))}:${p(Math.floor((ms % 60000) / 1000))},${p(ms % 1000, 3)}`;
};
let t0 = 0, n = 1, out = "";
for (const b of d.beats) {
  const kal = b.narasi.split(/(?<=[.?!])\s+/);
  const kata = kal.map((k) => k.split(/\s+/).length);
  const tot = kata.reduce((a, c) => a + c, 0);
  let t = t0 + 0.2;
  const rentang = b.dur - 0.5;
  kal.forEach((k, i) => {
    const dur = (rentang * kata[i]) / tot;
    out += `${n++}\n${f(t)} --> ${f(t + dur - 0.05)}\n${k}\n\n`;
    t += dur;
  });
  t0 += b.dur;
}
fs.mkdirSync("out", {recursive: true});
fs.writeFileSync("out/pompeii.srt", out);
console.log("SRT ditulis:", n - 1, "baris -> out/pompeii.srt");
