import React from "react";
import {Composition} from "remotion";
import {FaktaVideo} from "./FaktaVideo";
import {hitungDurasiFrame} from "./durasi";
import {UjiTangkiPecah} from "./clay/UjiTangkiPecah";
import {FPS, LEBAR, TINGGI} from "./styles/tema";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="FaktaNyeleneh"
        component={FaktaVideo}
        durationInFrames={hitungDurasiFrame()}
        fps={FPS}
        width={LEBAR}
        height={TINGGI}
      />
      <Composition
        id="UjiClay"
        component={UjiTangkiPecah}
        durationInFrames={180}
        fps={FPS}
        width={LEBAR}
        height={TINGGI}
      />
      {/* Versi 10 fps: tampilannya sama, tetapi render jauh lebih cepat */}
      <Composition
        id="UjiClay10"
        component={UjiTangkiPecah}
        durationInFrames={60}
        fps={10}
        width={LEBAR}
        height={TINGGI}
      />
    </>
  );
};
