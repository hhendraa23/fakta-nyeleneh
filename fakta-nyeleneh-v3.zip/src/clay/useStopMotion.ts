import {useCurrentFrame, useVideoConfig} from "remotion";

// Membekukan waktu agar gerakan terlihat patah-patah seperti stop-motion.
// Hasilnya selalu dalam satuan 30 fps, apa pun fps komposisinya, dan hanya
// berubah tiap `langkah` frame (3 = 10 gambar per detik).
export const useStopMotion = (langkah = 3): number => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const f30 = Math.round(frame * (30 / fps));
  return Math.floor(f30 / langkah) * langkah;
};
