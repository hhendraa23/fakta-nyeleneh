import React from "react";
import {AbsoluteFill} from "remotion";
import {useStopMotion} from "./useStopMotion";
import {buatAdegan} from "./adegan";
import {tema} from "../styles/tema";

// Adegan uji claymation. Seluruh gambar dibuat oleh buatAdegan() di adegan.ts.
export const UjiTangkiPecah: React.FC = () => {
  const f = useStopMotion(3);

  return (
    <AbsoluteFill style={{background: "linear-gradient(#a8cbe0, #dcebf3 60%)"}}>
      <svg
        width={1080}
        height={1920}
        viewBox="0 0 1080 1920"
        style={{position: "absolute", left: 0, top: 0}}
        dangerouslySetInnerHTML={{__html: buatAdegan(f)}}
      />
      <div
        style={{
          position: "absolute",
          top: 190,
          width: "100%",
          textAlign: "center",
          fontFamily: tema.font,
          fontSize: 64,
          fontWeight: 900,
          color: "#3b1f0e",
        }}
      >
        BOSTON, 15 JANUARI 1919
      </div>
    </AbsoluteFill>
  );
};
