#!/usr/bin/env bash
# Render cepat untuk gaya stop-motion:
# merender 10 gambar per detik, lalu menggandakannya menjadi 30 fps dengan FFmpeg.
# Pemakaian: bash render-cepat.sh <IdKomposisi10fps> <namaFile>
set -e
KOMPOSISI="${1:-UjiClay10}"
NAMA="${2:-uji-clay}"
mkdir -p out

npx remotion render src/index.ts "$KOMPOSISI" "out/${NAMA}-10fps.mp4"

if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "Memasang FFmpeg (gratis)..."
  sudo apt-get update -y
  sudo apt-get install -y ffmpeg
fi

ffmpeg -y -i "out/${NAMA}-10fps.mp4" -vf fps=30 -c:v libx264 -pix_fmt yuv420p -an "out/${NAMA}.mp4"
rm -f "out/${NAMA}-10fps.mp4"
echo "Selesai: out/${NAMA}.mp4"
